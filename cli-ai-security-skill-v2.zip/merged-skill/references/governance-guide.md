# AI Governance Guide

## Overview

AI governance provides the organizational framework for managing AI risks and ensuring responsible AI use. The OWASP AI Exchange emphasizes that AI security starts with governance — you cannot secure what you don't know you have.

This guide integrates the **G.U.A.R.D. Framework** from the Gemini version with the comprehensive Coze version governance guidance.

---

## The Five G.U.A.R.D. Steps

The G.U.A.R.D. framework provides a 5-stage lifecycle for operationalizing AI security across the organization.

```
┌─────────┐    ┌───────────┐    ┌────────┐    ┌────────┐    ┌────────────┐
│ GOVERN  │───▶│ UNDERSTAND│───▶│ ADAPT  │───▶│ REDUCE │───▶│ DEMONSTRATE│
└─────────┘    └───────────┘    └────────┘    └────────┘    └────────────┘
```

### 1. GOVERN — Establish AI Governance

**Objective**: Maintain centralized inventory of AI initiatives, perform business/privacy impact analyses, assign strict asset accountabilities, cross-reference with legal frameworks.

**Components**:
- Inventory of all AI initiatives
- Impact assessments for each initiative
- Risk management integration
- Responsibility assignments (model accountability, data accountability)
- Compliance management
- Education programs

**Key Question**: Is AI really needed to solve the problem?

**Engineering Implementation**:
- Central corporate register of AI initiatives
- Formal risk analysis documentation
- Clear asset ownership for training data, model parameters, output tracking
- Alignment verification with relevant regulatory frameworks (GDPR, EU AI Act)

### 2. UNDERSTAND — Know Your Threats

**Objective**: Map specific system architectures against structural decision trees to deduce which theoretical threats translate into actual technical risk.

**Process**:
1. Use the decision tree from risk analysis
2. Identify applicable threats for each system
3. Ensure engineers understand relevant threats
4. Distinguish organizational vs. supplier responsibilities

**4-Step Threat Modeling Workflow**:
- Step 1: Define System Architecture and Asset Boundaries
- Step 2: Trace the Lethal Trifecta Vector
- Step 3: Map System Assets to Vulnerability Matrix
- Step 4: Establish Continuous Validation Infrastructure

### 3. ADAPT — Extend Security Practices

**Objective**: Integrate new AI-specific data structures (weights, training corpuses, embeddings) into the Information Security Management System (ISMS) and Software Development Lifecycle (SDLC).

**Areas to Adapt**:
- Security assets inventory (add AI-specific assets)
- Threat modeling (add AI-specific threats)
- Testing (add AI-specific testing)
- Supply chain management (add data, models, hosting)
- Development practices (add AI engineering)

**Implementation**:
- Add AI-specific assets to security management system
- Extend threat models with AI-specific attack vectors
- Integrate AI security testing into CI/CD pipelines
- Adapt supply chain management for data, models, hosting

### 4. REDUCE — Limit Impact

**Objective**: Enforce data minimization, obfuscate training registers, manage least privileges for model interfaces, institute strict downstream human or rule-based guardrails.

**Strategies**:
- Data minimization and obfuscation
- Least model privilege
- Human oversight mechanisms
- Guardrails and safety controls
- Blast radius limitation
- Break the Lethal Trifecta (eliminate at least one condition)

**Key Controls**:
- #DATA MINIMIZE
- #OBFUSCATE TRAINING DATA
- #LEAST MODEL PRIVILEGE
- #OVERSIGHT
- #INPUT SEGREGATION
- #SENSITIVE OUTPUT HANDLING

### 5. DEMONSTRATE — Show Compliance

**Objective**: Generate cryptographic lineage documentation, validation audit trails, automated red-teaming telemetry to provide proof of compliance to auditors and executives.

**Methods**:
- Transparency documentation
- Testing evidence
- Audit trails
- Risk assessment records
- Control effectiveness metrics

**Deliverables**:
- Model cards and AIBOMs (AI Bill of Materials)
- Cryptographic provenance documentation
- Red team testing reports
- Compliance evidence packages
- Audit trail documentation

---

## AI Program Implementation

### Bare Minimum

1. **Inventory**: List all current AI use and ideas
2. **Risk Analysis**: Identify threats, controls, and responsibilities
3. **Continue**: Follow G.U.A.R.D. program step 2

### Full Implementation

#### Phase 1: Foundation (Weeks 1-4)

1. **Raise Awareness**
   - Board-level briefing on AI risks
   - Executive sponsorship
   - Budget allocation

2. **Form Governance Group**
   - Cross-functional team (security, legal, engineering, data science)
   - Clear roles and responsibilities
   - Regular meeting cadence

3. **Identify Regulations**
   - Applicable laws (GDPR, AI Act, sector-specific)
   - Industry standards (ISO, NIST)
   - Contractual obligations

#### Phase 2: Discovery (Weeks 4-8)

4. **AI Inventory**
   - Survey all departments
   - Document current AI use
   - Capture AI ideas/plans
   - Identify shadow AI

5. **Evaluate Applications**
   - Technical assessment
   - Risk assessment
   - Compliance check
   - Business value assessment

#### Phase 3: Risk Management (Weeks 8-12)

6. **Risk Analysis**
   - Threat identification (use decision tree)
   - Impact assessment
   - Control mapping
   - Risk register creation
   - Lethal Trifecta analysis for agentic systems

7. **Policy Development**
   - AI usage policy
   - Data handling policy
   - Model development standards
   - Supplier requirements

#### Phase 4: Implementation (Weeks 12+)

8. **Tool Implementation**
   - Governance tools
   - Risk management platforms
   - Monitoring systems

9. **Education Program**
   - AI security training
   - Role-specific training
   - Awareness campaigns

---

## Security Program Integration

### Extending Your ISMS

The Information Security Management System (ISMS) must be extended to include AI:

**New Assets to Add**:
- Training data
- Validation/test data
- Model parameters
- Hyperparameters
- Model documentation
- Model input/output
- Augmentation data (RAG, system prompts)
- AI development environments

**New Threats to Add**:
- All AI-specific threats from the taxonomy
- New attack surfaces (training, inference, supply chain)

**New Controls to Add**:
- AI-specific controls from the catalog
- Extended conventional controls for AI context

### AI Security Honeypots

Strategic use of honeypots to detect attackers:

| Honeypot Type | Description |
|--------------|-------------|
| Vulnerable data service | Elasticsearch with unpatched vulnerability |
| Fake data lake | Exposed but not revealing actual assets |
| Vulnerable API | Data access API vulnerable to brute-force |
| Mirror server | Resembles development facilities, exposed in production |
| Fake documentation | "Accidentally" exposed, directs to honeypot |
| Exposed library | Python data science library on server |
| External library access | Grant access to specific library |
| GitHub models | Models imported as-is from GitHub |

---

## Compliance Management

### Regulatory Landscape

#### European Union
- **AI Act**: Risk-based framework
  - Unacceptable risk: prohibited
  - High risk: strict requirements
  - Limited risk: transparency obligations
  - Minimal risk: no specific requirements
- **GDPR**: Personal data protection
- **AI Liability Directive**: Liability for AI harm
- **Product Liability Directive**: Product safety
- **prEN 18282**: European AI Security standard (in development)

#### United States
- **Federal AI Disclosure Act**: AI disclosure requirements
- **Algorithmic Accountability Act**: Impact assessments
- **State-level**: Various state AI laws
- **Secure AI System Development Guidelines**: Technical security focus

#### Other Jurisdictions
- **China**: Deep Synthesis Regulations, Generative AI Measures
- **Brazil**: AI Regulatory Framework
- **Canada**: Artificial Intelligence & Data Act
- **India**: Digital India Act

### ISO/IEC 27090 and 27091 Compliance

#### ISO/IEC 27090 (AI Security)

The OWASP AI Exchange provides the technical foundation for ISO/IEC 27090. Key compliance areas:

| ISO/IEC 27090 Requirement | AI Exchange Implementation |
|--------------------------|---------------------------|
| Parameter protection | #RUNTIME MODEL CONFIDENTIALITY, #MODEL OBFUSCATION |
| Data lineage tracking | #SUPPLY CHAIN MANAGE, provenance documentation |
| Inversion attack mitigation | #OBSCURE CONFIDENCE, #DATA MINIMIZE |
| Model integrity | #RUNTIME MODEL INTEGRITY |
| AI-specific threat coverage | Complete threat taxonomy |

#### ISO/IEC 27091 (AI Privacy)

| ISO/IEC 27091 Requirement | AI Exchange Implementation |
|--------------------------|---------------------------|
| Privacy by design for AI | #AI PROGRAM, DPIA processes |
| Data minimization in AI | #DATA MINIMIZE, #OBFUSCATE TRAINING DATA |
| Purpose limitation | #ALLOWED DATA |
| Privacy-preserving techniques | Federated learning, differential privacy |
| Data subject rights for AI | Right to erasure processes |
| Transparency | #AI TRANSPARENCY, #EXPLAINABILITY |

### Compliance Mapping

| Requirement | AI Exchange Controls |
|------------|---------------------|
| Risk assessment | Risk analysis section |
| Transparency | #AI TRANSPARENCY |
| Human oversight | #OVERSIGHT |
| Data governance | #DATA MINIMIZE, #ALLOWED DATA |
| Accuracy | #CONTINUOUS VALIDATION, #DATA QUALITY CONTROL |
| Robustness | #CONTINUOUS VALIDATION, #TRAIN ADVERSARIAL |
| Security | All relevant controls |
| Record keeping | #SUPPLY CHAIN MANAGE (provenance) |

### AI Act Flow

```
Is your AI system in scope?
├─ Prohibited (unacceptable risk) → Cannot deploy
├─ High risk → Strict requirements:
│   ├─ Risk management system
│   ├─ Data governance
│   ├─ Technical documentation
│   ├─ Transparency
│   ├─ Human oversight
│   ├─ Accuracy, robustness, cybersecurity
│   └─ Conformity assessment
├─ Limited risk → Transparency obligations
│   └─ Inform users they're interacting with AI
└─ Minimal risk → No specific requirements
    └─ But general AI security still applies
```

---

## Organizational Structure

### Roles and Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **AI Governance Lead** | Overall AI governance program |
| **AI Security Lead** | AI-specific security risks and controls |
| **Model Owner** | Accountable for specific AI models |
| **Data Owner** | Accountable for training/evaluation data |
| **AI Engineers** | Implement security controls in models |
| **Security Team** | Integrate AI into security operations |
| **Legal/Compliance** | Regulatory compliance and policy |
| **Data Protection Officer** | Privacy compliance |

### RACI Matrix Example

| Activity | AI Gov Lead | AI Security | Model Owner | AI Engineer | Security Team |
|----------|-------------|-------------|-------------|-------------|---------------|
| AI Inventory | A | C | C | I | I |
| Threat Modeling | C | A | C | R | R |
| Control Implementation | I | C | A | R | C |
| Risk Assessment | A | R | C | C | R |
| Incident Response | C | A | C | R | R |
| Compliance | A | C | C | I | C |

R=Responsible, A=Accountable, C=Consulted, I=Informed

---

## Shadow AI Management

### The Problem

Employees access ready-made AI models (ChatGPT, Claude, etc.) without organizational oversight, potentially exposing sensitive data.

### Solutions

1. **Provide Better Alternatives**
   - Deploy secure, privacy-preserving AI models
   - Ensure sufficient quality
   - Comply with organizational policies

2. **Make Risks Clear**
   - Training on shadow AI risks
   - Clear policies on acceptable use
   - Consequences for violations

3. **Technical Controls**
   - Network controls (where appropriate)
   - DLP (Data Loss Prevention) integration
   - Monitoring for unauthorized AI use

4. **Cultural Approach**
   - Enable rather than just restrict
   - Provide secure alternatives
   - Regular awareness updates

---

## Metrics and KPIs

### Governance Metrics

| Metric | Description | Target |
|--------|-------------|--------|
| AI Inventory Coverage | % of AI systems documented | 100% |
| Risk Assessment Coverage | % of AI systems with risk assessment | 100% |
| Control Implementation | % of required controls implemented | >90% |
| Training Completion | % of relevant staff trained | >95% |
| Incident Response Time | Time to respond to AI incidents | <24 hours |
| Compliance Score | Regulatory compliance level | Pass all audits |

### Security Metrics

| Metric | Description |
|--------|-------------|
| Threat Detection Rate | % of threats detected vs. total |
| Control Effectiveness | Measured reduction in risk |
| Vulnerability Management | Time to patch AI vulnerabilities |
| Supply Chain Coverage | % of suppliers assessed |
| Testing Coverage | % of AI systems tested |

---

## Production Security Implementation Checklist

### 1. AI Governance & Compliance
- [ ] The system has been added to the central corporate register of AI initiatives
- [ ] A formal risk analysis has been conducted
- [ ] Asset ownership for training data, model parameters, and output tracking has been clearly assigned
- [ ] Alignment with relevant regulatory frameworks (GDPR, EU AI Act) has been verified

### 2. Supply Chain Security
- [ ] Base model weights from external registries are verified using cryptographic hash checks
- [ ] Open-source components, training libraries, and data ingestion tools are scanned for known vulnerabilities
- [ ] Clear agreements or contractual protections are in place regarding data retention and model training policies of external API providers

### 3. Data Protection & Lifecycle Management
- [ ] Sensitive data points have been minimized or obfuscated within the training and fine-tuning datasets
- [ ] Access permissions for data pipelines and the MLOps engineering environment follow the principle of least privilege
- [ ] Vector databases and RAG indices are protected against unauthorized modification and data leakage

### 4. Runtime & Boundary Protection
- [ ] The user-facing prompt layer is decoupled from structural system instructions using structured message formats or API role separation
- [ ] Input filters are active to intercept and block known injection patterns, adversarial variations, and abnormal inputs
- [ ] Rate limits and token consumption thresholds are configured to prevent resource exhaustion and DoS attempts

### 5. Output Management & Execution Safety
- [ ] Model output is treated as untrusted data and goes through strict validation or encoding before being used in downstream code paths
- [ ] The model runs with the minimal system privileges required for its operational tasks, preventing unverified privilege escalation
- [ ] Human verification or explicit rule boundaries are required before the system can execute irreversible actions or process sensitive data mutations

---

## References

- ISO/IEC 42001: AI Management System
- ISO/IEC 27001/27002: Information Security Management
- ISO/IEC 5338: AI Lifecycle
- ISO/IEC 27090 (AI Security): https://www.iso.org/standard/68207.html
- ISO/IEC 27091 (AI Privacy): https://www.iso.org/standard/68208.html
- EU AI Act: https://artificialintelligenceact.eu/
- UNESCO AI Ethics: https://www.unesco.org/en/artificial-intelligence
- OWASP AI Exchange: https://owaspai.org
- GenAI Security Project: LLM AI Cybersecurity & Governance Checklist
