# OWASP AI Exchange Framework Overview

## What is the AI Exchange?

The OWASP AI Exchange is the world's most comprehensive AI security guide — 300+ pages of free, constantly-evolving, practical guidance on securing AI systems. It represents the closest publicly available alignment of global expert consensus, feeding directly into the EU AI Act and ISO standards through unique SDO partnerships.

### Key Characteristics

- **AUTHORITATIVE**: Active alignment with ISO/IEC and EU AI Act through official partnerships
- **OPEN**: Any expert can contribute; strong quality assurance with author screening
- **FREE**: No copyright restrictions (CC0 1.0)
- **COMPREHENSIVE**: Covers ALL AI types — Analytical, Discriminative, Generative, heuristic systems
- **UNIFIED**: Single coherent resource instead of fragmented documents
- **CLEAR**: Explains the why and how, not just the what
- **LINKED**: References other sources; serves as the starting hub
- **EVOLVING**: Continuous updates instead of occasional publications

### FOUNDATION Principles

- **F** – Fundamentals: comprehensive threat & control model
- **O** – One integrated body of knowledge
- **U** – Universal: covers all AI & data-centric systems
- **N** – No copyright restrictions
- **D** – Data & privacy included
- **A** – Aligned with international standards
- **T** – Technically grounded (engineering-oriented)
- **I** – Iteratively updated
- **O** – Open contribution
- **N** – Networked bridge between standards, researchers, practitioners

## Scope of Coverage

### AI Types Covered

1. **Generative AI (GenAI)**: Large Language Models (LLMs), image generators, etc.
2. **Predictive AI**: Classification, regression, recommendation systems
3. **Agentic AI**: Autonomous agents, multi-agent systems
4. **Heuristic AI**: Expert systems, rule-based systems
5. **Data-centric systems**: Big data systems without AI models

### Security Definition

Security means preventing unauthorized:
- Access
- Use
- Disclosure
- Disruption
- Modification (including manipulating AI model behavior)
- Destruction

## Core Tenets of AI Security Assurance

These tenets define the fundamental principles that distinguish AI security from traditional software security:

### 1. Inductive Nature Risks

**Traditional software is deductive**: Rule-based code processes data deterministically according to explicit instructions.

**Machine Learning is inductive**: It defines behavior based on statistical data distributions, meaning **being wrong is an intrinsic property of the model**.

**Security Implications**:
- Models will always produce incorrect outputs for some inputs
- Adversaries can exploit statistical patterns to manipulate behavior
- Traditional input validation alone is insufficient
- Must assume models can be fooled, manipulated, or induced to produce harmful outputs

### 2. Fluidity of Boundaries

Large Language Models (LLMs) treat **instructions (system prompts) and data interchangeably** within the context window.

**This causes a complete breakdown of classic code/data trust boundaries**:
- User-provided text can be interpreted as system instructions
- External data (RAG, retrieved documents) can override system behavior
- No inherent distinction between "code" and "data" in the prompt

**Security Implications**:
- Input sanitization alone cannot prevent prompt injection
- Must implement defense in depth (sanitization + segregation + monitoring)
- System prompts are not secure boundaries
- Assume all user input and external data is potentially malicious

### 3. Zero Model Trust

Security mechanisms **must assume that any model can be manipulated, fooled, or induced to leak information under optimal adversarial conditions**.

**Controls must focus on both**:
1. **Hardening the asset**: Make the model more resistant to attacks
2. **Limiting the blast radius**: Contain the damage when attacks succeed

**Security Implications**:
- No model is 100% secure against all attacks
- Layer defenses to limit impact of successful attacks
- Assume worst-case scenarios in threat modeling
- Design systems to fail gracefully

## Document Structure

The AI Exchange is organized into these main sections:

### Section 0: AI Security Overview
- Introduction and essentials
- Threat landscape overview
- Risk analysis methodology
- Organization guidance (GUARD framework)

### Section 1: General Controls
- 1.1 Governance controls (AI Program, SEC Program, etc.)
- 1.2 Data limitation controls
- 1.3 Controls to limit unwanted behavior

### Section 2: Input Threats
- 2.1 Evasion attacks
- 2.2 Prompt injection (direct and indirect)
- 2.3 Sensitive data disclosure
- 2.4 Model exfiltration
- 2.5 AI resource exhaustion

### Section 3: Development-time Threats
- 3.1 Model poisoning (data poisoning, direct, supply chain)
- 3.2 Sensitive data leaks

### Section 4: Runtime Conventional Security Threats
- 4.1 Generic security threats
- 4.2 Direct runtime model poisoning
- 4.3 Direct runtime model leak
- 4.4 Output injection
- 4.5-4.7 Input/augmentation data threats

### Section 5: AI Security Testing
- Testing methodologies
- Red teaming tools
- Automated testing frameworks

### Section 6: AI Privacy
- Privacy concerns
- Legislative considerations
- Assessment frameworks

### Section 7: References
- Journal papers, standards, tools

## Integration with Industry Standards

### ISO/IEC Standards

| Standard | Focus | Coverage |
|----------|-------|----------|
| ISO/IEC 42001 | AI Management System | Governance, risk management |
| ISO/IEC 27001 | Information Security | General security management |
| ISO/IEC 27002 | Security Controls | Detailed control implementation |
| ISO/IEC 27005 | Security Risk Management | Risk assessment processes |
| **ISO/IEC 27090** | **AI Security** | **AI-specific security — AI Exchange provides technical foundation** |
| **ISO/IEC 27091** | **AI Privacy** | **AI-specific privacy — AI Exchange provides technical foundation** |
| ISO/IEC 5338 | AI Lifecycle | Complete software lifecycle for AI |
| ISO/IEC 23894 | AI Risk Management | AI-specific risk management |
| ISO/IEC 24028 | AI Trustworthiness | AI trustworthiness assessment |
| ISO/IEC 24029-2 | Neural Network Robustness | Adversarial robustness assessment |
| ISO/IEC 24027 | Bias in AI Systems | Bias identification and mitigation |

### NIST Frameworks

| Framework | Focus |
|-----------|-------|
| NIST AI RMF | AI Risk Management Framework |
| NIST SP 800-53 | General security/privacy controls |
| NIST Cybersecurity Framework | Cybersecurity risk management |
| NIST AI 100-2 | AI-specific security guidance |

### Other Frameworks

| Framework | Focus |
|-----------|-------|
| MITRE ATLAS | Adversarial tactics, techniques, procedures |
| EU AI Act | European AI regulation |
| OWASP Top 10 for LLM | LLM-specific top risks |
| ENISA | European cybersecurity guidance |

## Organizing AI Security: The G.U.A.R.D. Framework

### 1. Govern
Implement general AI Governance:
- Know where AI is applied
- Establish responsibilities
- Create policies
- Perform impact assessments
- Arrange compliance
- Organize education

### 2. Understand
Understand which threats apply:
- Use the decision tree in risk analysis section
- Ensure engineers understand relevant threats and controls
- Distinguish between organizational and supplier responsibilities

### 3. Adapt
Adapt security practices:
- Include AI security assets, threats, and controls
- Extend threat modeling with AI-specific approaches
- Adapt testing to include AI-specific security testing
- Adapt supply chain management for data, models, hosting

### 4. Reduce
Reduce potential impact:
- Minimize or obfuscate sensitive data
- Limit impact of unwanted behavior
- Manage privileges
- Implement guardrails and human oversight

### 5. Demonstrate
Establish evidence of responsible AI security:
- Transparency
- Testing
- Documentation
- Communication

## Key Principles for AI Security

### Defense in Depth
Multiple layers of security controls are essential. No single control is sufficient.

### Least Privilege
Minimize what models can do — both in terms of actions and data access.

### Data Minimization
Limit the amount of sensitive data exposed at all times.

### Continuous Validation
Ongoing monitoring and testing of model behavior.

### Supply Chain Security
Secure all components: data, models, hosting, dependencies.

### Privacy by Design
Integrate privacy considerations from the start.

### Zero Model Trust
Assume models can be compromised; design systems to limit blast radius.

## AI-Specific Security Considerations

### Why AI Security is Different

1. **Inductive rather than deductive**: Being wrong is part of the game for ML models
2. **Models can go stale**: Performance degrades over time
3. **Data-driven behavior**: Data is both opportunity and risk source
4. **Unfamiliar to organizations**: Risk of implementation mistakes
5. **Incomprehensible**: Trust issues due to lack of interpretability
6. **New technical assets**: Data/model supply chain, parameters, augmentation data
7. **Natural language interface**: Can listen, speak, see, hear
8. **Uncertainty**: Security measures cannot offer same properties as traditional software

### Critical Insight

> "Securing AI is typically harder than securing non-AI systems, first because it's relatively new, but also because there is a level of uncertainty in all data-driven technology."

### When to Question AI Use

Before building an AI solution, consider:
- Is AI really needed to solve the problem?
- Can the required transparency be provided?
- Can privacy rights be achieved?
- Can unwanted behavior be sufficiently contained?
- Is the right expertise available?
- Is it allowed to use the data for the purpose?

**Removing an unnecessary AI component eliminates all AI-related risks.**

## AI Security Matrix

The AI Security Matrix organizes threats by:
1. **AI-specific?** — Whether the threat is unique to AI
2. **Lifecycle** — When the threat occurs (development/runtime)
3. **Attack Surface** — How the threat manifests
4. **Threat/Risk category** — What is threatened
5. **Asset impacted** — What is at risk
6. **Potential harm** — What damage could occur

### Asset Categories

- **Model behavior integrity**: Model performs as intended
- **Training data confidentiality**: Training data remains secret
- **Model confidentiality**: Model parameters remain secret
- **Model behavior availability**: Model remains operational
- **Model input data confidentiality**: Input data remains secret
- **Augmentation data confidentiality**: RAG/system prompt data remains secret
- **Any asset (CIA)**: General IT security

## Periodic Table of AI Security

The Periodic Table provides a visual organization of all threats and controls, structured by:
- Asset type
- Impact category
- Attack surface
- Lifecycle phase
- Control categories

This serves as a quick reference for identifying relevant threats and controls for specific AI system configurations.

## Additional Resources

- **OWASP AI Exchange**: https://owaspai.org
- **Threat Advisor**: AI-powered threat modeling tool
- **OpenCRE**: https://opencre.org
- **PwnzzAI**: Hacking lab for AI security practice
- **MITRE ATLAS**: https://attack.mitre.org/matrices/enterprise/
- **ISO/IEC 27090 (AI Security)**: https://www.iso.org/standard/68207.html
- **ISO/IEC 27091 (AI Privacy)**: https://www.iso.org/standard/68208.html
