# AI Security Controls Catalog

## Overview

The OWASP AI Exchange organizes security controls into several categories that work together as defense-in-depth. Controls are mapped to specific threats and lifecycle phases.

**Critical Principle**: Select and implement controls with care. Many controls are expensive and involve trade-offs with other AI properties (accuracy, performance). Controls that change learning processes can have unintended downstream side effects.

---

## Control Categories Overview

### Category 1: AI Governance Controls
Integrate AI comprehensively into information security and software development lifecycle.

### Category 2: Supply Chain Management
Extend supply chain management with governance of data, models, and model hosting.

### Category 3: Conventional Security Controls
Apply standard security controls to AI-specific assets.

### Category 4: AI Engineer Security Controls
Specialized controls requiring AI/data science expertise.

### Category 5: Data Limitation Controls
Minimize and obfuscate sensitive data.

### Category 6: Behavior Limitation Controls
Limit the impact of unwanted model behavior.

---

## 1. GOVERNANCE CONTROLS

### #AI PROGRAM — AI Governance Program

**Objective**: Take responsibility for AI as an organization; ensure all AI initiatives are known and under control.

**Implementation**:
- Keep inventory of AI initiatives
- Perform impact analysis on initiatives
- Organize AI innovation processes
- Include AI risks in risk management
- Assign responsibilities (model accountability, data accountability, risk governance)
- AI literacy programs (training)
- Organize compliance
- Incorporate AI assets into security program

**Impact Analysis Considerations**:
- Can the required transparency be provided?
- Can privacy rights be achieved (access, erase, correct, update, object)?
- Can unwanted bias be sufficiently mitigated?
- Is AI really needed to solve the problem?
- Is the right expertise available?
- Is it allowed to use the data for this purpose?
- Can unwanted behavior be sufficiently contained?

**Quickstart**:
1. Raise attention at board level
2. Form stakeholder group and assign responsibilities
3. Identify laws and regulations
4. Survey for AI inventory (current use, ideas, concerns, expertise)
5. Evaluate AI applications and ideas
6. Perform risk analysis and establish initial policy
7. Implement policy in tools and procedures
8. Initiate AI literacy program

**Minimum Start**:
1. Inventory current AI use and ideas
2. Perform risk analysis (threats, controls, responsibilities)
3. Continue with G.U.A.R.D. program step 2

**Related Standards**: ISO/IEC 42001, AI Governance Library, UNESCO AI Ethics

### #SEC PROGRAM — Security Program

**Objective**: Ensure adequate mitigation of AI security risks through information security management.

**Implementation**:
- Include AI-specific assets in security management system:
  - Training/validation/test data
  - Model parameters
  - Hyperparameters
  - Documentation
  - Model input/output
  - Intended model behavior
  - External data/models
  - Augmentation data (RAG, system prompts)
- Perform privacy and security risk analysis for each AI initiative
- Include AI-specific honeypots:
  - Hardened data services with unpatched vulnerabilities
  - Exposed data lakes (not revealing actual assets)
  - Vulnerable data access APIs
  - Mirror data servers
  - "Accidentally" exposed documentation
  - Exposed Python libraries
  - Models imported from GitHub

**Related Standards**: ISO 27000-27005, ISO 27090, ISO 27091, ISO 5338, ISO 23894, ISO 24028, NIST AI RMF, NIST SP 800-53, MITRE ATLAS

### #SEC DEV PROGRAM — Secure Development Program

**Objective**: Reduce security risks by building security into AI during development.

**Implementation**:
- Extend existing secure development practices to include AI teams
- Data science development activities become part of general SDLC:
  - Secure development training
  - Code review
  - Security requirements
  - Secure coding guidelines
  - Threat modeling (including AI-specific threats)
  - Static analysis tooling
  - Dynamic analysis tooling
  - Penetration testing
- No isolated secure development framework for AI needed

**AI Particularities**:
- New engineering types: data engineering, model engineering
- New engineer types: data scientists, data engineers, AI engineers
- Version management of code + configuration + training data + models
- New assets, threats, controls affect requirements, policies, guidelines
- Supply chain includes data and models (not just code)

**Related Standards**: ISO/IEC 5338, OWASP SAMM, NIST SSDF

### #DEV PROGRAM — Development Lifecycle Program

**Objective**: Apply general software engineering best practices to AI development.

**Implementation**:
- Mix data scientist profiles with software engineering profiles
- Continuously measure quality aspects of data science code
- Provide coaching to data scientists on maintainability and testing
- AI-specific engineering practices:
  - Data provenance & lineage
  - Model traceability
  - AI-specific testing (continuous validation, staleness, concept drift)

### #CHECK COMPLIANCE — Compliance Checking

**Objective**: Ensure AI-relevant laws and regulations are considered in compliance management.

**Global Regulations** (as of late 2023):
- **Canada**: Artificial Intelligence & Data Act
- **USA**: Federal AI Disclosure Act, Algorithmic Accountability Act
- **Brazil**: AI Regulatory Framework
- **India**: Digital India Act
- **Europe**: AI Act, AI Liability Directive, Product Liability Directive
- **China**: Deep Synthesis Regulations, Generative AI Measures

**Non-Security Considerations**:
- Ethics (deep fake weaponization)
- Human Control (keep human in the loop)
- Discrimination (review datasets for bias)
- Transparency (Trust by Design)
- Accountability

**Related Standards**: ISO 27002 Control 5.36, prEN 18282 (European AI Security), ISO 27090, ISO 27091

### #SEC EDUCATE — Security Education

**Objective**: Ensure engineers and security professionals understand AI threats and controls.

**Implementation**:
1. Based on AI inventory, identify applicable threats
2. Ensure understanding of relevant threats and controls
3. Use courses and resources for support
4. Distinguish organizational vs. supplier responsibilities

---

## 2. DATA LIMITATION CONTROLS

### #DATA MINIMIZE — Data Minimization

**Objective**: Minimize impact of data leakage by reducing data processed.

**Implementation**:
- Remove unused/low-impact fields and records
- Remove elements that don't materially affect model performance
- Retain identifiers only for data removal requests
- Update training datasets to reflect upstream removals/corrections
- Preserve original data separately with access controls

**AI Particularity**: AI models often tolerate reduced feature sets better than traditional applications.

### #ALLOWED DATA — Allowed Data Verification

**Objective**: Remove data prohibited for the intended purpose.

**Key Concern**: Consent and purpose limitation — especially for personal data collected for different purposes.

### #SHORT RETAIN — Short Retention

**Objective**: Remove or anonymize data when no longer needed or legally required.

**Implementation**: Limit retention periods as special form of data minimization; comply with privacy regulations.

### #OBFUSCATE TRAINING DATA — Training Data Obfuscation

**Objective**: Attain obfuscation of sensitive data when it cannot be removed entirely.

**Techniques**:

#### PATE (Private Aggregation of Teacher Ensembles)
- Ensemble of teacher models trained on disjoint data subsets
- Student model trained on aggregated, noised predictions
- Balances privacy and accuracy

#### Objective Function Perturbation
- Add controlled noise to learning algorithm's objective function
- Calibrated to sensitivity and desired privacy level (epsilon)
- Trade-off: more noise = more privacy but less accuracy

#### Masking
- Alter/replace sensitive features with alternative representations
- Methods: tokenization, perturbation, generalization, feature engineering
- Balance privacy with model utility

#### Encryption
- Two models: (1) data always encrypted for data scientists, or (2) encrypted at rest but used in original form
- Asymmetric encryption (Paillier, Elgamal) for unpredictable pseudonyms
- Homomorphic encryption for computation on ciphertexts
- Must combine with proper access control

#### Tokenization
- Replace sensitive information with unique tokens
- Aligns with differential privacy principles
- Particularly useful for development-time data science

---

## 3. BEHAVIOR LIMITATION CONTROLS

### #OVERSIGHT — Human/Automated Oversight

**Objective**: Monitor and control model behavior to prevent unwanted outcomes.

**Implementation**:
- Human-in-the-loop for critical actions
- Automated detection of suspicious activity
- Context-aware oversight logic
- Consider approval fatigue

### #LEAST MODEL PRIVILEGE — Least Model Privilege

**Objective**: Minimize what a model can do (actions and data access) to prevent harm from manipulation or mistakes.

**Implementation**:
- Limit permissions and attack surface
- Honor limitations of the served (user/service)
- Task-based minimization (reduce to minimum for foreseeable use cases)
- **Do NOT implement authorization in GenAI instructions** (vulnerable to prompt injection)

**Strategies for Task-Based Minimization**:
1. **Harden based on general intent**: Minimize based on foreseeable use cases
2. **Harden based on prompt intent**: Use LLM to interpret intent and set permissions
3. **Harden based on role assignment**: Minimize based on assigned task role
4. **Harden based on risk elevation**: Increase restrictions when untrusted data enters flow
5. **Downgrade subagents**: Inter-agent calls include reduced permission sets
6. **Hardening as incident response**: Reduce blast radius based on suspicion level
7. **Ephemeral permissions**: Temporary permissions that expire

**Flexibility Balance**: Trade-off between general-purpose agent (easy but risky) vs. many specialized agents (secure but complex).

### #MODELALIGNMENT — Model Alignment

**Objective**: Ensure model behavior is consistent with human values and intentions by baking it into the model.

**Implementation Layers**:
1. **Training-Time Alignment**: Training data choices, fine-tuning on aligned examples, RLHF
2. **Deployment-Time Alignment**: System prompts, guardrails, content filters

**Advantages over External Controls**:
- Can capture complex behavioral boundaries through examples
- Flexible recognition of unwanted behavior using model's judgment

**Limitations**:
- Reliability issues (prone to manipulation, imperfect memorization)
- Boundaries may change after training
- Must be combined with deterministic external mechanisms for high-risk use

### #AI TRANSPARENCY — AI Transparency

**Objective**: Inform users about AI system properties so they can adjust reliance and apply mitigations.

**Information to Provide**:
- Rough working of the model
- Training approach
- Type and source of data used
- Expected accuracy and robustness
- Residual security risks

**Note**: Transparency is about abstract system information, not decision explainability.

### #CONTINUOUS VALIDATION — Continuous Validation

**Objective**: Detect unexpected model behavior changes indicating manipulation, system failures, or drift.

**Implementation**:
- **Timing**: After training/retraining, before deployment, periodically during operation
- **Degradation Detection**: Monitor for unexpected performance changes
- **Response Options**: Investigate, continue (if acceptable), rollback, restrict usage, add oversight, disable
- **Test Data Management**: Store test data separately from training data
- **Metrics**: Correctness, bias, robustness — aligned with system goals

**Limitations**:
- Not suitable for detecting backdoor poisoning (designed to pass validation)
- Relies on representativeness and integrity of test dataset
- Does not replace other integrity and monitoring controls

**Related Standards**: ISO 5338, ISO/IEC 24029-2, ISO/IEC 24027, ISO/IEC 25059

### #EXPLAINABILITY — Explainability

**Objective**: Explain individual model decisions to gain trust and prevent overreliance.

**Security Value**: Helps security assessors evaluate AI security risks.

### #UNWANTED BIAS TESTING — Unwanted Bias Testing

**Objective**: Detect unwanted behavior caused by attacks through bias measurement.

**Implementation**: Run test runs to measure unwanted bias; detect changes from attacks.

---

## 4. INPUT THREAT CONTROLS

### #MONITOR USE — Monitor Usage

**Objective**: Observe, correlate, and log model usage to identify security incidents.

**Implementation**:
- Log date, time, user, inputs, outputs, system behavior
- Detect: improper functioning, suspicious patterns, suspicious inputs
- Add model version and output details to logs
- Integrate with existing incident detection processes

### #RATE LIMIT — Rate Limiting

**Objective**: Limit the number of interactions to prevent attacks requiring many queries.

### #MODELACCESS CONTROL — Model Access Control

**Objective**: Reduce the number of potential attackers to a minimum.

### #ANOMALOUS INPUT HANDLING — Anomalous Input Handling

**Objective**: Detect and handle unusual inputs that may indicate attacks.

**Implementation**: Establish out-of-distribution (OOD) isolation metrics or measure spatial reconstruction errors at inference API layers to block incoming vectors that diverge significantly from expected distributions.

### #UNWANTED INPUT SERIES HANDLING — Unwanted Input Series Handling

**Objective**: Detect patterns across multiple inputs that indicate attacks (e.g., model extraction, gradual manipulation).

### #OBSCURE CONFIDENCE — Obscure Confidence Scores

**Objective**: Hide confidence scores to prevent attackers from efficiently crafting adversarial examples.

**Rationale**: Many attacks rely on rich output information (confidence scores).

### #EVASION INPUT HANDLING — Evasion Input Handling

**Objective**: Handle inputs that may be evasion attacks.

### #EVASION ROBUST MODEL — Evasion-Robust Model

**Objective**: Build models that are inherently robust against evasion attacks.

### #TRAIN ADVERSARIAL — Adversarial Training

**Objective**: Train model to be more robust against evasion and poisoning attacks.

**Implementation**:
- Generate adversarial examples using attack methods (e.g., PGD)
- Include adversarial examples in training set with correct output
- Model learns not to rely on subtle patterns
- Note: significant training overhead, may not generalize to new attacks

### #INPUT DISTORTION — Input Distortion

**Objective**: Modify inputs slightly to disrupt adversarial attacks while maintaining correctness.

**Techniques**:
- Adding noise (randomization)
- Smoothing
- JPEG compression
- Random Transformations (RT)

**Against Evasion**: Distorted input breaks carefully crafted perturbations. Use dual-path approach: undistorted + distorted input; if results differ strongly, likely attack.

**Against Data Poisoning**: Disrupts poisoning features (e.g., high-frequency noise, visible patches).

### #ADVERSARIAL ROBUST DISTILLATION — Robust Distillation

**Objective**: Train student model to replicate softened teacher outputs, smoothing decision boundaries.

**Caution**: Security concerns exist about effectiveness of defensive distillation.

### #PROMPT INJECTION I/O HANDLING — Prompt Injection I/O Handling

**Objective**: Detect, contain, and respond to unwanted behavior from crafted instructions.

**Implementation**:
1. **Sanitize characters**: Unicode normalization (NFKC), character filtering, remove zero-width characters
2. **Escape instruction-like tokens**: Transform tokens that may be mistaken for real instructions (fences, role markers, XML tags, tool calling tokens)
3. **Delineate untrusted data**: Use input segregation (#INPUT SEGREGATION)
4. **Recognize manipulative instructions**: Pattern detection + LLM-as-a-judge for semantic detection
5. **Apply input handling upstream**: Sanitize as early as possible
6. **Detect unwanted output**: Content detection, grounding checks
7. **Update detections constantly**: Use external sources, open source tools
8. **Respond to detections**: Filter, stop processing, or alert

**Detection Tools**: Guardrails-AI, Langkit, LLM Guard, NVIDIA NeMo Guardrails, Rebuff

**Engineering Implementation**: Deploy lightweight, high-speed secondary structural models (classifiers or guardrail layers) directly at system entrance and exit gates to inspect incoming prompts and outgoing generations for malicious instructional payloads.

### #INPUT SEGREGATION — Input Segregation

**Objective**: Clearly separate user-provided data from system instructions to prevent indirect prompt injection.

**Engineering Implementation**: Structurally separating trusted system instructions from untrusted data blocks within model APIs. For LLMs, this requires encoding inputs via strict structured serialization schemas (e.g., separate JSON schemas or explicit role boundaries like `system`, `user`, and `tool`) rather than simple string concatenations.

### #SENSITIVE OUTPUT HANDLING — Sensitive Output Handling

**Objective**: Filter or modify model output to prevent disclosure of sensitive information.

### #SMALL MODEL — Use Smaller Models

**Objective**: Reduce attack surface for model extraction and inversion attacks.

### #MODELWATERMARKING — Model Watermarking

**Objective**: Embed watermarks in models to detect unauthorized copying.

### #DOS INPUT VALIDATION — DoS Input Validation

**Objective**: Validate inputs to prevent resource exhaustion attacks.

### #LIMIT RESOURCES — Limit Resources

**Objective**: Limit computational resources available per request/user to prevent exhaustion.

---

## 5. DEVELOPMENT-TIME CONTROLS

### #DEV SECURITY — Development Environment Security

**Objective**: Secure AI development infrastructure and its sensitive assets.

**Implementation**:
- Add AI-specific assets to security management system
- Encryption of data at rest
- Technical access control (least privilege)
- Centralized access control
- Operational security
- Logging and monitoring
- Integrity checking:
  - **Build stage**: Source code verification, dependency management, automated testing
  - **Deploy stage**: Environment configuration, secure deployment, runtime integrity monitoring
  - **Supply chain**: Component authenticity (cryptographic signatures)

**Model Signing**: Cryptographic signing of models (similar to SSL/Authenticode) — consider all artifacts: code, data, tokenizers, vocab files, configs, inference code. OpenSSF Model Signing SIG working on specification.

**Data Integrity**: Verify dataset entries through hashing; be aware that URL-based datasets (e.g., LAION-400M) are vulnerable to poisoning through content changes.

### #SEGREGATE DATA — Data Segregation

**Objective**: Store sensitive development data in separated areas with restricted access.

**Example Segregation**:
1. External (for externally obtained data)
2. Application development environment
3. Data engineering environment
4. Training environment
5. Operational environment (for runtime-collected data)

### #CONF COMPUTE — Confidential Compute

**Objective**: Hide training data and model parameters from engineers even during use.

### #FEDERATED_LEARNING — Federated Learning

**Objective**: Train on distributed data without centralizing it.

**Benefits**: Regulatory compliance, enhanced confidentiality, scalability, data diversity.

**Challenges**:
- Data disclosure risk still exists (from model weights)
- Central party can potentially extract user data
- More attack surface for poisoning
- Device heterogeneity
- Broadcast latency and security
- Querying data creates risk

### #SUPPLY CHAIN MANAGE — Supply Chain Management

**Objective**: Minimize security risk from externally obtained elements.

**AI Supply Chain Particularities**:
1. Three new supplied assets: data, models, model hosting
2. May include own organization (data/models from different departments)
3. New AI-specific development tooling
4. Tools may run development-time (access to sensitive assets)

**Implementation**:
- **Provenance & Traceability**: Origin/versioning of models and datasets, checksums, training data sources, dependencies, ownership — maintain as Model Cards, AIBOMs, MBOMs
- **Lifecycle Updates**: Update records at meaningful points (development, version releases, deployment, architecture changes, new datasets, dependency updates)
- **Integrity & Verification**: Checksum/hash verification, signed attestations, content-addressable storage, periodic audits
- **Supplier Evaluation**: Reputation, activity, security posture, development environments, provenance claims, contractual assurances
- **Additional Assessment**: Validate model formats, inspect architectures, test runtime behavior in isolation
- **Governance Enrichment**: Expanded asset records, contractual/legal risk coverage, version management integration, vulnerability management alignment

---

## 6. RUNTIME CONVENTIONAL SECURITY CONTROLS

### #RUNTIME MODEL INTEGRITY — Runtime Model Integrity

**Objective**: Ensure deployed model has not been tampered with.

### #RUNTIME MODEL IO INTEGRITY — Runtime Model I/O Integrity

**Objective**: Ensure inputs and outputs are not tampered with in transit.

### #RUNTIME MODEL CONFIDENTIALITY — Runtime Model Confidentiality

**Objective**: Protect deployed model from unauthorized access.

**Implementation**: Trusted Execution Environments (TEEs), encryption, access controls.

### #MODEL OBFUSCATION — Model Obfuscation

**Objective**: Make model harder to understand/extract.

### #ENCODE MODEL OUTPUT — Encode Model Output

**Objective**: Prevent model output from being interpreted as code by downstream systems.

**Implementation**: Proper encoding for HTML, SQL, etc. to prevent XSS, SQL injection, etc.

### #MODEL INPUT CONFIDENTIALITY — Model Input Confidentiality

**Objective**: Protect input data from unauthorized access.

### #AUGMENTATION DATA CONFIDENTIALITY — Augmentation Data Confidentiality

**Objective**: Protect RAG data, system prompts, and other augmentation data.

### #AUGMENTATION DATA INTEGRITY — Augmentation Data Integrity

**Objective**: Ensure augmentation data has not been manipulated.

### #MODEL ENSEMBLE — Model Ensemble

**Objective**: Use multiple models to reduce impact of any single compromised model.

### #MORE TRAIN DATA — More Training Data

**Objective**: Increase training data volume to reduce impact of poisoning.

### #DATA QUALITY CONTROL — Data Quality Control

**Objective**: Ensure training data quality to detect anomalies.

### #TRAIN DATA DISTORTION — Training Data Distortion

**Objective**: Apply distortion techniques to training data for robustness.

### #POISON ROBUST MODEL — Poison-Robust Model

**Objective**: Design models to be robust against poisoning attacks.

### #DISCRETE — Discrete Operation

**Objective**: Balance between transparency and discretion about model use.

---

## Control Selection Decision Framework

```
For each identified threat:

1. GOVERNANCE: Is there an AI governance program? (AI PROGRAM, SEC PROGRAM)
2. DATA LIMITATION: Can sensitive data be reduced? (DATA MINIMIZE, ALLOWED DATA, SHORT RETAIN, OBFUSCATE)
3. PREVENTION: Can the attack be prevented?
   - Access control (MODELACCESS CONTROL, DEV SECURITY)
   - Input validation (PROMPT INJECTION I/O HANDLING, INPUT SEGREGATION)
   - Robust training (TRAIN ADVERSARIAL, EVASION ROBUST MODEL)
4. DETECTION: Can the attack be detected?
   - Monitoring (MONITOR USE, CONTINUOUS VALIDATION)
   - Anomaly detection (ANOMALOUS INPUT HANDLING)
5. MITIGATION: Can impact be reduced?
   - Least privilege (LEAST MODEL PRIVILEGE)
   - Oversight (OVERSIGHT)
   - Output handling (SENSITIVE OUTPUT HANDLING, ENCODE MODEL OUTPUT)
   - Resource limits (RATE LIMIT, LIMIT RESOURCES)
6. RECOVERY: Can the system recover?
   - Model rollback
   - Retrain strategies
   - Failover mechanisms
```

---

## Control Priority Matrix

| Priority | Controls | Rationale |
|----------|----------|-----------|
| **Critical** | AI Program, Security Program, Secure Dev Program | Foundation for everything else |
| **High** | Data Minimize, Least Model Privilege, Oversight | Directly limit blast radius |
| **High** | Supply Chain Manage, Dev Security | Prevent development-time attacks |
| **High** | Prompt Injection I/O Handling | Key defense for GenAI |
| **High** | Input Segregation | Critical for indirect prompt injection |
| **Medium** | Continuous Validation, Monitor Use | Detect attacks in progress |
| **Medium** | Sensitive Output Handling | Defense in depth |
| **Medium** | Adversarial Training, Evasion Robust Model | Specific attack prevention |
| **Lower** | Obscure Confidence, Model Watermarking | Reduce attack efficiency |
| **Always** | Rate Limit, Resource Limits, Encode Output | Basic hygiene |

---

## Engineering Implementation Quick Reference

| Control | Implementation Parameter |
|---------|-------------------------|
| #INPUT SEGREGATION | Strict JSON schemas, explicit role boundaries (system/user/tool) |
| #TRAIN ADVERSARIAL | Integrate adversarial perturbations into formal training data loops |
| #DATA MINIMIZE | Strip identifiable variables, add statistical noise (differential privacy) |
| #ANOMALOUS INPUT HANDLING | OOD isolation metrics, spatial reconstruction error measurement |
| #PROMPT INJECTION I/O HANDLING | Lightweight secondary classifiers at API entrance/exit gates |
| #LEAST MODEL PRIVILEGE | Schema checks + deterministic filters for tool invocations; required human validation for sensitive mutations |
