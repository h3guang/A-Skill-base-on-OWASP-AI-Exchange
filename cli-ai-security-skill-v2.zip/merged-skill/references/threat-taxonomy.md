# AI Threat Taxonomy — Complete Classification

## Overview

The OWASP AI Exchange classifies AI security threats into a comprehensive taxonomy organized by:
- **Target Asset**: What is being attacked
- **Attack Surface**: How the attack reaches the target
- **Lifecycle Phase**: When the attack occurs
- **Impact Category**: CIA triad (Confidentiality, Integrity, Availability)

Each threat is documented with the **Mechanism / Impact / Controls** format for engineering clarity.

---

## Threat Impact Categories

All AI threats map to three attacker goals:

1. **Disclose**: Hurt confidentiality of train/test data, model IP, or input data
2. **Deceive**: Hurt integrity of model behavior (manipulated to behave unwantedly)
3. **Disrupt**: Hurt availability of the model

---

## Category 1: Model Behavior Integrity Threats

These threats aim to manipulate the model to behave in unwanted ways.

### 1.1 Direct Prompt Injection

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Type** | GenAI (LLMs only) |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack (user provides input) |

**Mechanism**: The end-user intentionally crafts system-breaking prompts or adversarial payloads designed to override system alignment rules, bypass structural guardrails, or manipulate output generation.

**Impact**: Generation of toxic, copyrighted, or highly restricted content; execution of unvetted backend function calls; unauthorized data access.

**Controls**: #PROMPT INJECTION I/O HANDLING, #MODEL ALIGNMENT, #OVERSIGHT

**Attack Strategies:**
- Role-playing and conditioning ("act as an unrestricted expert")
- Overriding system instructions ("ignore previous instructions")
- Encoding tricks (base64, emojis, spelling mistakes)
- Split attacks (breaking harmful prompt into pieces)
- Non-text inputs (hidden instructions in images, audio)
- Forcing hidden context revelation
- Manipulating input/output formats
- Gradual manipulation over multiple turns
- Extremely long prompts to overwhelm safety

**Jailbreak Strategies:**
1. Abusing competing objectives (helpfulness vs. safety)
2. Using out-of-distribution input that bypasses alignment

### 1.2 Indirect Prompt Injection

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Type** | GenAI with data insertion |
| **Lifecycle** | Runtime |
| **Attack Surface** | Untrusted data inserted into prompt |

**Mechanism**: A third party places malicious instructions inside external unstructured data sources (web pages, third-party documents, vector database stores) that are dynamically read and executed by an LLM agent.

**Impact**: Silent privilege escalation, dynamic data exfiltration via the user's session context, unauthorized account compromise.

**Controls**: #INPUT SEGREGATION, #PROMPT INJECTION I/O HANDLING, #LEAST MODEL PRIVILEGE

**Key Scenarios:**
- RAG systems retrieving manipulated documents
- Agents accessing compromised data sources
- Email/document processing with hidden instructions
- Multimodal inputs (images with embedded text instructions)

### 1.3 Evasion Attacks (Adversarial Machine Learning)

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Type** | Predictive AI (classification tasks) |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack (manipulated data, not instructions) |

**Mechanism**: An adversary applies imperceptible mathematically designed perturbations to test-time inputs (e.g., adding slight noise to fraud logs or image pixels) to induce high-confidence misclassifications.

**Impact**: Complete bypass of production security filters, spam detectors, facial recognition cameras, or anomalous transaction controls.

**Controls**: #EVASION ROBUST MODEL, #TRAIN ADVERSARIAL, #INPUT DISTORTION, #ANOMALOUS INPUT HANDLING, #EVASION INPUT HANDLING

**Attack Variants:**

#### Zero-Knowledge (Black Box) Evasion
- Attacker has no knowledge of model internals
- Query-based approach: systematically probe model
- **Decision-based**: Only top prediction label revealed
- **Score-based**: Confidence scores revealed (more feedback)

#### Perfect-Knowledge (White Box) Evasion
- Full knowledge of architecture, parameters, weights
- Can calculate gradients for efficient attacks
- Famous example: Fast Gradient Sign Method (FGSM)
- Most powerful attack type

#### Transferability-Based Evasion
- Create adversarial examples on surrogate model
- Transfer to target model
- Surrogate can be: similar model, stolen model, self-trained model
- Works because similar tasks have similar decision boundaries

#### Partial-Knowledge (Gray Box) Evasion
- Middle ground between black and white box
- Some knowledge of architecture or training data
- More efficient than zero-knowledge attacks

#### Evasion After Data Poisoning (Backdoor)
- Vulnerability is manipulated, not natural
- Specific triggers cause unwanted output
- Backdoors designed to pass validation tests

### 1.4 Direct Runtime Model Poisoning

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack on AI asset) |
| **Lifecycle** | Runtime |
| **Attack Surface** | Break into deployed model |

**Mechanism**: Compromising the target server environment via classic OS-level or application-level vulnerabilities to directly overwrite or modify saved model parameter serialization files (e.g., pickle formats, safe-tensors) on disk or in system memory.

**Impact**: Instant modification of target system outputs without triggering detection vectors located inside training data validation controls.

**Controls**: #RUNTIME MODEL INTEGRITY, #RUNTIME MODEL IO INTEGRITY

### 1.5 Direct Development-time Model Poisoning

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack on AI asset) |
| **Lifecycle** | Development |
| **Attack Surface** | Engineering environment |

**Mechanism**: Attacker breaks into development environment and alters model during development/training.

**Impact**: Manipulated model behavior from development stage.

**Controls**: #DEV SECURITY, #DATA SEGREGATION

### 1.6 Data Poisoning

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Development |
| **Attack Surface** | Training/finetune data |

**Mechanism**: Injecting carefully crafted corrupt or malicious records into the training, fine-tuning, or alignment datasets prior to training phases. This includes planting specific trigger conditions ("backdoors") that cause predictable runtime misbehavior only when the trigger is present.

**Impact**: Complete degradation of foundational accuracy metrics or permanent insertion of hidden logic switches that bypass defensive classification checkpoints.

**Controls**: #DATA QUALITY CONTROL, #POISON ROBUST MODEL, #TRAIN ADVERSARIAL, #TRAIN DATA DISTORTION, #MORE TRAIN DATA, #MODEL ENSEMBLE

**Poisoning Techniques:**
- Label flipping: changing correct labels
- Feature manipulation: altering input features
- Backdoor/triggers: embedding specific patterns
- Clean-label attacks: maintaining correct labels while changing features
- Adversarial sample injection

### 1.7 Supply Chain Model Poisoning

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Partially |
| **Lifecycle** | Development |
| **Attack Surface** | Supply chain |

**Mechanism**: Downloading pre-trained model weights or foundational model distributions from untrusted repositories (e.g., public registries) that contain hidden malicious weights, embedded backdoors, or vulnerability-inducing patterns.

**Impact**: Complete subversion of enterprise internal security alignment properties directly at initialization.

**Controls**: #SUPPLY CHAIN MANAGE, #MODEL ENSEMBLE

### 1.8 Supply Chain Data Poisoning

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Development |
| **Attack Surface** | Supply chain |

**Mechanism**: Obtaining poisoned data from external sources that corrupts model training.

**Impact**: Model trained on manipulated data with degraded accuracy or backdoors.

**Controls**: #SUPPLY CHAIN MANAGE, #DATA QUALITY CONTROL

### 1.9 Augmentation Data Manipulation

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Runtime |
| **Attack Surface** | Augmentation data (RAG, system prompts, memory) |

**Mechanism**: Manipulating data inserted into model input (RAG databases, system prompts, working memory) to influence model behavior.

**Impact**: Model behavior influenced by manipulated context without direct access to the model.

**Controls**: #INPUT SEGREGATION, #AUGMENTATION DATA INTEGRITY, #PROMPT INJECTION I/O HANDLING

---

## Category 2: Training Data Confidentiality Threats

### 2.1 Disclosure in Model Output

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack (model use) |

**Mechanism**: Model reveals sensitive training data in its output due to memorization or insufficient safeguards.

**Impact**: Unauthorized access to training data, compliance violations.

**Controls**: #DATA MINIMIZE, #SENSITIVE OUTPUT HANDLING, #SHORT RETAIN

### 2.2 Model Inversion

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack |

**Mechanism**: An attacker repeatedly queries an inference API endpoint and calculates variance across output probability distributions or confidence levels to reconstruct elements of the private training set.

**Impact**: Loss of private medical identities, intellectual property leaks, compliance violations under GDPR/AI Act regulations.

**Controls**: #OBSCURE CONFIDENCE, #SMALL MODEL, #UNWANTED INPUT SERIES HANDLING, #DATA MINIMIZE

### 2.3 Membership Inference

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack |

**Mechanism**: Determining whether specific data was in the training set by analyzing model outputs and confidence patterns.

**Impact**: The fact of being in the dataset is revealed (sensitive when dataset membership is sensitive).

**Controls**: #OBSCURE CONFIDENCE, #DATA MINIMIZE, #UNWANTED INPUT SERIES HANDLING

**Example**: Training set of criminals — membership reveals someone is a convicted criminal.

### 2.4 Direct Training Data Leak

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack) |
| **Lifecycle** | Development |
| **Attack Surface** | Engineering environment |

**Mechanism**: Direct access to training data through compromised development environment.

**Impact**: Training data stolen.

**Controls**: #DEV SECURITY, #SEGREGATE DATA, #CONF COMPUTE

---

## Category 3: Model Confidentiality Threats

### 3.1 Model Exfiltration (Functional Extraction)

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Yes |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack (input-output harvesting) |

**Mechanism**: Systematically harvesting large-scale input/output queries from a target model to train a local proxy architecture that replicates the proprietary model's precise execution dynamics.

**Impact**: Severe devaluation of corporate capital investments, loss of competitive market advantage, and cheaper offline creation of highly optimized evasion attacks.

**Controls**: #RATE LIMIT, #MODEL ACCESS CONTROL, #UNWANTED INPUT SERIES HANDLING, #MODEL WATERMARKING

### 3.2 Direct Runtime Model Leak

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack) |
| **Lifecycle** | Runtime |
| **Attack Surface** | Break into deployed model |

**Mechanism**: Direct access to model parameters through compromised deployment environment.

**Impact**: Model parameters stolen.

**Controls**: #RUNTIME MODEL CONFIDENTIALITY, #MODEL OBFUSCATION

### 3.3 Direct Development-time Model Leak

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack) |
| **Lifecycle** | Development |
| **Attack Surface** | Engineering environment |

**Mechanism**: Model stolen from development environment.

**Impact**: Model parameters stolen.

**Controls**: #DEV SECURITY, #SEGREGATE DATA

---

## Category 4: Availability Threats

### 4.1 AI Resource Exhaustion

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | Partially |
| **Lifecycle** | Runtime |
| **Attack Surface** | Input attack (model use) |

**Mechanism**: Flooding endpoints with highly complex, recursively nested prompts, oversized context windows, or input tokens designed to trigger excessive combinatorial processing times.

**Impact**: Financial starvation due to runaway API token bills; denial of service (DoS) for production applications.

**Controls**: #DOS INPUT VALIDATION, #LIMIT RESOURCES, #RATE LIMIT

---

## Category 5: Input Data Confidentiality Threats

### 5.1 Input Data Leak

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack) |
| **Lifecycle** | Runtime |
| **Attack Surface** | All IT |

**Mechanism**: Sensitive input data leaked through conventional attacks on infrastructure.

**Impact**: Unauthorized access to input (e.g., prompts with sensitive questions).

**Controls**: #MODEL INPUT CONFIDENTIALITY, #ENCODE MODEL OUTPUT

---

## Category 6: Augmentation Data Threats

### 6.1 Direct Augmentation Data Leak

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No (conventional attack) |
| **Lifecycle** | Runtime |
| **Attack Surface** | Break into deployed system |

**Mechanism**: Intercepting or extracting prompt history, contextual information derived via Retrieval-Augmented Generation (RAG), or vector database queries at rest, in memory, or in transit.

**Impact**: Unencrypted exposure of corporate secrets, raw developer telemetry, and private individual identifiers transferred beyond secure microservices.

**Controls**: #MODEL INPUT CONFIDENTIALITY, #AUGMENTATION DATA CONFIDENTIALITY, #CONF COMPUTE

### 6.2 Augmentation Data Manipulation

(See 1.9 above)

---

## Category 7: Conventional Security Threats

### 7.1 Output Contains Conventional Injection

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No |
| **Lifecycle** | Runtime |
| **Attack Surface** | All IT |

**Mechanism**: Model output contains injection attacks (XSS, SQL injection, etc.) that are executed by downstream systems.

**Impact**: C,I,A of any asset through injection.

**Controls**: #ENCODE MODEL OUTPUT, #SENSITIVE OUTPUT HANDLING

### 7.2 Generic Runtime Security Threats

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No |
| **Lifecycle** | Runtime |
| **Attack Surface** | All IT |

**Mechanism**: Standard IT security threats (includes social engineering/phishing).

**Impact**: C,I,A of any asset.

**Controls**: Standard security controls apply

### 7.3 Conventional Development/Supply Chain Threats

| Attribute | Detail |
|-----------|--------|
| **AI-specific** | No |
| **Lifecycle** | Development |
| **Attack Surface** | All IT |

**Mechanism**: Standard development environment and supply chain attacks.

**Impact**: C,I,A of any asset.

**Controls**: Standard security controls apply

---

## Agentic AI Specific Threats

### The Lethal Trifecta

For data exfiltration in agentic AI, three conditions must be met:

```
┌─────────────────────────────────────────────────────────────┐
│  1. UNTRUSTED DATA PIPELINE                                │
│     Attacker controls input vector that automatically       │
│     loads into LLM context window (web scrapers, user       │
│     forms, emails, resumes) triggering Indirect Prompt      │
│     Injection                                             │
│                                                             │
│  2. PRIVILEGED ACCESS                                      │
│     Executing model or agent holds authenticated           │
│     programmatic access (APIs, read/write permissions)    │
│     to sensitive backend databases, corporate secrets,       │
│     or transactional environments                          │
│                                                             │
│  3. AUTONOMOUS TRANSMISSION                                │
│     Model possesses open outbound channel or connected     │
│     action (mail invocation, webhook execution, dynamic    │
│     URL rendering) capable of pushing structured data      │
│     out of trust boundary                                  │
│                                                             │
│  ALL THREE = CATASTROPHIC DATA EXFILTRATION               │
│  Missing ANY ONE = Attack Fails                           │
└─────────────────────────────────────────────────────────────┘
```

### Key Agentic AI Properties Creating Threats

1. **Action**: Agents invoke functions (email, code execution) → LEAST MODEL PRIVILEGE critical
2. **Autonomous**: Agents trigger each other → OVERSIGHT important; working memory is attack vector
3. **Complex**: Emergent behavior → Hard to predict security implications
4. **Multi-system**: Multiple systems and interfaces → Access control assigned to AI via instructions (vulnerable to prompt injection)

### Agentic AI Attack Surfaces

- Working memory (state and plan storage)
- Inter-agent communication (e.g., MCP)
- Memory integrity
- Privilege escalation through confused deputy attacks
- Prompt injection as key threat in most agentic systems

---

## Threat Map by Lifecycle Phase

### Development-time Threats
- Data poisoning
- Direct development-time model poisoning
- Supply chain model poisoning
- Supply chain data poisoning
- Direct training data leak
- Direct development-time model leak
- Source code/configuration leak
- Conventional development threats

### Runtime Input Threats
- Direct prompt injection
- Indirect prompt injection
- Evasion attacks (all variants)
- Disclosure in output
- Model inversion
- Membership inference
- Model exfiltration
- AI resource exhaustion
- Input data leak

### Runtime Conventional Threats
- Direct runtime model poisoning
- Direct runtime model leak
- Output contains conventional injection
- Augmentation data manipulation
- Direct augmentation data leak
- Generic runtime security threats

---

## Quick Reference: When Does Each Threat Apply?

| Threat | Condition |
|--------|-----------|
| Direct prompt injection | Model is GenAI + attacker can provide input |
| Indirect prompt injection | Model is GenAI + system inserts untrusted data |
| Evasion | Model performs classification + adversary influences input |
| Data poisoning | You train your own model |
| Supply chain model poisoning | Model is from a supplier |
| Augmentation data manipulation | System inserts data into model input (RAG, prompts) |
| Disclosure in output | You train model + training data is sensitive |
| Model inversion/membership inference | You train model + data sensitivity criteria met |
| Model exfiltration | Model is intellectual property or susceptible to evasion |
| AI resource exhaustion | Always possible |
| Input data leak | Input data is sensitive |
| Output injection | Output text is interpreted downstream |
| Lethal Trifecta | Agentic AI + all three conditions present |

---

## Control Reference Matrix

| Threat | Primary Controls |
|--------|-----------------|
| Direct Prompt Injection | #PROMPT INJECTION I/O HANDLING, #MODEL ALIGNMENT, #OVERSIGHT |
| Indirect Prompt Injection | #INPUT SEGREGATION, #PROMPT INJECTION I/O HANDLING, #LEAST MODEL PRIVILEGE |
| Evasion Attacks | #EVASION ROBUST MODEL, #TRAIN ADVERSARIAL, #INPUT DISTORTION |
| Model Inversion/Membership Inference | #OBSCURE CONFIDENCE, #SMALL MODEL, #DATA MINIMIZE |
| Model Exfiltration | #RATE LIMIT, #MODEL ACCESS CONTROL, #MODEL WATERMARKING |
| Data Poisoning | #DATA QUALITY CONTROL, #POISON ROBUST MODEL, #MODEL ENSEMBLE |
| Supply Chain Model Poisoning | #SUPPLY CHAIN MANAGE, #MODEL ENSEMBLE |
| AI Resource Exhaustion | #DOS INPUT VALIDATION, #LIMIT RESOURCES, #RATE LIMIT |
| Training Data Disclosure | #DATA MINIMIZE, #OBFUSCATE TRAINING DATA, #SENSITIVE OUTPUT HANDLING |
| Runtime Model Poisoning | #RUNTIME MODEL INTEGRITY, #RUNTIME MODEL IO INTEGRITY |
| Augmentation Data Leakage | #MODEL INPUT CONFIDENTIALITY, #AUGMENTATION DATA CONFIDENTIALITY |
| Output Injection | #ENCODE MODEL OUTPUT, #SENSITIVE OUTPUT HANDLING |
| Lethal Trifecta | Break any of the three conditions |
