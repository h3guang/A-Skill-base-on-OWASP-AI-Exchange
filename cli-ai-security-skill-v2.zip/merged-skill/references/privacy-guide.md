# AI Privacy Guide

## Overview

AI systems introduce unique privacy challenges beyond traditional IT systems. The OWASP AI Exchange integrates privacy considerations throughout its framework, recognizing that privacy = personal data protection + respect for further individual rights.

---

## Privacy Concerns of AI Systems

### Why AI Privacy is Different

1. **Data-Driven**: AI systems require large amounts of data, often personal
2. **Inference**: AI can infer personal information from non-personal data
3. **Persistence**: Models encode patterns from training data that may be hard to remove
4. **Opacity**: Model decisions are often not interpretable
5. **Scale**: AI systems can process and correlate data at unprecedented scale
6. **Emergent Properties**: Models may learn unexpected patterns from data

### Privacy-Specific AI Threats

| Threat | Description | Privacy Impact |
|--------|-------------|----------------|
| **Membership Inference** | Determine if individual was in training data | Reveals association with sensitive group |
| **Model Inversion** | Reconstruct training data from model | Reconstructs personal information |
| **Data Disclosure in Output** | Model reveals training data in responses | Direct personal data leakage |
| **Attribute Inference** | Infer attributes about individuals | Profiling, discrimination |
| **Re-identification** | Link anonymized data back to individuals | Loss of anonymity |
| **Training Data Leak** | Direct access to training data | Complete data exposure |

---

## Legislative Framework

### GDPR (EU General Data Protection Regulation)

Key provisions for AI systems:

| Article | Requirement | AI Implication |
|---------|-------------|----------------|
| Art. 5 | Data minimization, purpose limitation | Limit training data to what's necessary |
| Art. 6 | Lawful basis for processing | Need lawful basis for training data |
| Art. 9 | Special category data | Extra protections for sensitive data in AI |
| Art. 13-14 | Transparency obligations | Inform data subjects about AI processing |
| Art. 15 | Right of access | Individuals can ask about their data in AI |
| Art. 17 | Right to erasure | Must remove data from training sets |
| Art. 21 | Right to object | Must handle objections to AI processing |
| Art. 22 | Automated decision-making | Rights around profiling and automated decisions |
| Art. 25 | Data protection by design | Privacy must be built into AI systems |
| Art. 35 | DPIA | Required for high-risk AI processing |

### EU AI Act

Risk-based framework with privacy intersection:
- High-risk AI systems must meet additional requirements
- Transparency obligations for AI systems
- Human oversight requirements
- Intersects with GDPR for personal data processing

### Other Global Regulations

| Regulation | Region | Key Points |
|-----------|--------|------------|
| CCPA/CPRA | California | Consumer rights, opt-out for data sharing |
| LGPD | Brazil | Similar to GDPR, data protection for AI |
| PIPEDA | Canada | Consent-based, reasonable purposes |
| APPI | Japan | Personal data protection for AI |
| Digital India Act | India | AI-specific provisions under development |
| AI Safety Standards | Australia | Risk-based guidance |

---

## Privacy Assessments

### 1. Use Limitation and Purpose Specification

**Key Questions**:
- Is the AI system used only for specified, explicit purposes?
- Is processing compatible with original collection purposes?
- Are there policies limiting AI system use?

**Implementation**:
- Document purposes for each AI system
- Implement technical controls to enforce purpose limitations
- Regular audits of AI system usage
- Clear policies on acceptable use

### 2. Fairness

**Key Questions**:
- Does the AI system treat individuals fairly?
- Are there discriminatory outcomes?
- Are protected characteristics handled appropriately?

**Implementation**:
- Bias testing (see #UNWANTED BIAS TESTING)
- Fairness metrics monitoring
- Regular equity audits
- Diverse development teams

**AI Exchange Control**: #UNWANTED BIAS TESTING

### 3. Data Minimization and Storage Limitation

**Key Questions**:
- Is only necessary data collected for AI training?
- Is data retained only as long as needed?
- Can the same results be achieved with less data?

**Implementation**:
- Data minimization during collection
- Regular data retention reviews
- Automated deletion when retention expires
- Feature selection to reduce data needs

**AI Exchange Controls**: #DATA MINIMIZE, #SHORT RETAIN, #ALLOWED DATA

### 4. Transparency

**Key Questions**:
- Are individuals informed about AI processing?
- Is the AI system's logic explainable?
- Can individuals understand how decisions are made?

**Implementation**:
- Clear privacy notices mentioning AI
- AI transparency to users (see #AI TRANSPARENCY)
- Explainability mechanisms (see #EXPLAINABILITY)
- Documentation of AI decision logic

**AI Exchange Controls**: #AI TRANSPARENCY, #EXPLAINABILITY

### 5. Privacy Rights

**Key Questions**:
- Can individuals exercise their data protection rights?
- Is there a process for access, correction, deletion?
- Can individuals object to AI processing?

**Implementation**:
- Processes for data subject requests
- Technical ability to remove data from training sets
- Mechanisms to correct inaccurate data
- Objection handling procedures

**Challenges for AI**:
- Removing data from trained models is difficult
- Right to erasure may require model retraining
- Automated decision-making objections need processes

### 6. Data Accuracy

**Key Questions**:
- Is training data accurate and up-to-date?
- Are there mechanisms to correct inaccurate data?
- Is data quality monitored?

**Implementation**:
- Data quality controls (see #DATA QUALITY CONTROL)
- Regular data validation
- Feedback mechanisms for data correction
- Continuous validation (see #CONTINUOUS VALIDATION)

### 7. Consent

**Key Questions**:
- Is valid consent obtained for AI processing?
- Can consent be withdrawn?
- Is consent specific and informed?

**Implementation**:
- Clear consent mechanisms
- Granular consent options
- Easy withdrawal processes
- Consent tracking systems

**Special Considerations**:
- Consent for training data may differ from consent for inference
- Children's data requires special protection
- Employment context may not allow free consent

### 8. Model Attacks (Privacy-Specific)

**Key Questions**:
- Is the model vulnerable to privacy attacks?
- Are privacy-enhancing technologies implemented?
- Is differential privacy used where appropriate?

**Implementation**:
- Privacy risk assessment
- Differential privacy implementation
- Training data obfuscation (see #OBFUSCATE TRAINING DATA)
- Regular privacy attack testing

**AI Exchange Controls**: #OBFUSCATE TRAINING DATA, #SMALL MODEL, #OBSCURE CONFIDENCE

---

## Privacy Before You Start

### Privacy Restrictions on AI Use

Before deploying AI, consider privacy restrictions:

1. **Legal basis required**: You need a lawful basis under GDPR Art. 6 for processing personal data in AI systems
2. **Purpose limitation**: Can only use data for compatible purposes
3. **Special category data**: Extra restrictions for sensitive data (health, biometrics, etc.)
4. **Transfer restrictions**: International data transfer limitations
5. **Automated decisions**: Additional restrictions for solely automated decisions with legal effects

### Privacy-Preserving AI Techniques

| Technique | Description | Use Case |
|-----------|-------------|----------|
| **Differential Privacy** | Mathematical guarantee of privacy | Training data protection |
| **Federated Learning** | Train without centralizing data | Distributed data scenarios |
| **Homomorphic Encryption** | Compute on encrypted data | Privacy-preserving inference |
| **Secure Multi-Party Computation** | Joint computation without revealing inputs | Collaborative training |
| **PATE** | Private aggregation of teacher ensembles | Knowledge transfer with privacy |
| **Synthetic Data** | Generate artificial training data | When real data not essential |
| **Anonymization** | Remove identifiers from data | Reduce privacy risk |

### When NOT to Use AI

Consider whether AI is appropriate:
- Can the problem be solved without AI?
- Is the required transparency achievable?
- Can privacy rights be respected?
- Is there a lawful basis for processing?
- Are the risks acceptable?

**Remember**: Removing an unnecessary AI component eliminates all AI-related risks, including privacy risks.

---

## Privacy Impact Assessment (PIA/DPIA)

### When Required

- High-risk processing (GDPR Art. 35)
- Large-scale processing of personal data
- Systematic monitoring
- Special category data processing
- Automated decision-making with legal effects
- Large-scale public monitoring

### AI-Specific DPIA Considerations

1. **Data flows**: Map all data flows into and out of the AI system
2. **Training data**: Document sources, types, volumes, sensitivity
3. **Model outputs**: Assess privacy risks in model outputs
4. **Third parties**: Consider data sharing with model providers
5. **Retention**: How long is data used/stored?
6. **Rights**: How are data subject rights handled?
7. **Transfers**: International data transfers?
8. **Mitigation**: Technical and organizational measures

---

## Supply Chain Privacy

### Provider-Hosted Models

Privacy questions for external AI providers:
1. **Where does the model run?** In vendor's processes or your VPC?
2. **What are data retention rules?** Court-ordered retention?
3. **What is logged and monitored?** Read the fine print
4. **Is input used for training?** Usually not, but verify
5. **Data processing agreements**: In place and sufficient?

**Critical**: Provider-hosted models need your input data in clear text. Your sensitive data exists unencrypted outside your infrastructure.

### Privacy Controls for Supply Chain

- Data Processing Agreements (DPAs)
- Standard Contractual Clauses (SCCs) for transfers
- Privacy impact assessments of providers
- Contractual privacy guarantees
- Right to audit provisions
- Data return/deletion requirements

---

## Privacy Testing

### Privacy-Specific Tests

- [ ] **Membership Inference Testing**: Can attackers determine training data membership?
- [ ] **Model Inversion Testing**: Can attackers reconstruct training data?
- [ ] **Data Extraction Testing**: Does the model output training data?
- [ ] **Attribute Inference Testing**: Can attackers infer attributes?
- [ ] **Re-identification Testing**: Can anonymized data be re-identified?
- [ ] **Linkability Testing**: Can data from different AI systems be linked?

### Tools and Techniques

- Privacy meter tools
- Membership inference attack libraries
- Model inversion frameworks
- Differential privacy verification
- Data leakage testing

---

## ISO/IEC 27091 (AI Privacy) Alignment

ISO/IEC 27091 provides AI-specific privacy guidance that aligns with the AI Exchange:

| ISO/IEC 27091 Area | AI Exchange Controls |
|--------------------|---------------------|
| Privacy governance | #AI PROGRAM, #SEC PROGRAM |
| Data minimization | #DATA MINIMIZE, #SHORT RETAIN, #ALLOWED DATA |
| Purpose limitation | #ALLOWED DATA, AI Program governance |
| Transparency | #AI TRANSPARENCY, #EXPLAINABILITY |
| Data subject rights | Privacy rights processes, #SHORT RETAIN |
| Privacy-preserving techniques | #OBFUSCATE TRAINING DATA, #FEDERATED LEARNING |
| Privacy impact assessment | DPIA/PIA processes |
| Supply chain privacy | #SUPPLY CHAIN MANAGE (privacy extension) |

---

## Quick Reference: Privacy Controls

| Privacy Principle | AI Exchange Controls |
|-------------------|---------------------|
| Data Minimization | #DATA MINIMIZE, #ALLOWED DATA, #SHORT RETAIN |
| Purpose Limitation | #ALLOWED DATA, AI Program governance |
| Transparency | #AI TRANSPARENCY, #EXPLAINABILITY |
| Accuracy | #DATA QUALITY CONTROL, #CONTINUOUS VALIDATION |
| Storage Limitation | #SHORT RETAIN |
| Integrity & Confidentiality | #OBFUSCATE TRAINING DATA, #DEV SECURITY, #DATA MINIMIZE |
| Accountability | #AI PROGRAM, #SEC PROGRAM, #CHECK COMPLIANCE |

---

## References

- GDPR: https://gdpr-info.eu/
- EU AI Act: https://artificialintelligenceact.eu/
- ISO/IEC 27091 (AI Privacy) — in development
- ISO/IEC 23894 (AI Risk Management) — includes privacy
- ENISA: AI Data Protection
- NIST AI 100-2: Privacy considerations
- OWASP AI Exchange Privacy Section: https://owaspai.org/go/privacy/
