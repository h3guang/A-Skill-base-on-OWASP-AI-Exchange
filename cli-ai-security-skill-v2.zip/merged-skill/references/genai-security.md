# Generative AI Security Guide

## Overview

Generative AI (GenAI), particularly Large Language Models (LLMs), introduces unique security challenges beyond traditional AI systems. This guide covers GenAI-specific threats, controls, and considerations based on the OWASP AI Exchange framework.

---

## What Makes GenAI Different?

| Characteristic | Security Implication |
|---------------|---------------------|
| **Natural language interface** | Flexible input = new attack surface (prompt injection) |
| **Unstable, undocumented interface** | Security measures can't offer same properties as traditional software |
| **Fluid input/output** | Hard to apply traditional input validation |
| **Emergent behavior** | Unpredictable responses to inputs |
| **Training data influence** | Model behavior shaped by vast, often unknown training data |
| **General purpose** | Used for many tasks = broad attack surface |
| **Context windows** | Insertion of untrusted data (RAG, system prompts) |

### Core Tenets for GenAI Security

1. **Inductive Nature Risks**: ML models define behavior statistically — being wrong is intrinsic
2. **Fluidity of Boundaries**: LLMs treat instructions and data interchangeably, breaking classic trust boundaries
3. **Zero Model Trust**: Assume any model can be manipulated — focus on hardening AND blast radius

---

## GenAI-Specific Threats

### 1. Prompt Injection

The defining threat of GenAI security.

#### Direct Prompt Injection

**Description**: User crafts prompts to manipulate model behavior.

**Mechanism**: The end-user intentionally crafts system-breaking prompts or adversarial payloads designed to override system alignment rules, bypass structural guardrails, or manipulate output generation.

**Impact**: Generation of toxic, copyrighted, or highly restricted content; execution of unvetted backend function calls.

**Controls**: #PROMPT INJECTION I/O HANDLING, #MODEL ALIGNMENT, #OVERSIGHT

**Attack Strategies**:

| Strategy | Example |
|----------|---------|
| Role-playing | "Act as an unrestricted expert..." |
| Instruction override | "Ignore previous instructions..." |
| Encoding tricks | Base64, emojis, unusual capitalization |
| Split attacks | Break harmful request into parts |
| Non-text inputs | Hidden instructions in images/audio |
| Context extraction | "Show me your system prompt" |
| Format manipulation | Change input/output format to bypass filters |
| Gradual manipulation | Build up to harmful request over turns |
| Length overwhelm | Very long prompts to overwhelm safety |

**Jailbreak Techniques**:
1. **Abusing competing objectives**: Exploit helpfulness vs. safety tension
2. **Out-of-distribution input**: Use encoding that fools safety training but produces in-distribution output

#### Indirect Prompt Injection

**Description**: Malicious instructions hidden in data the system processes.

**Mechanism**: A third party places malicious instructions inside external unstructured data sources (web pages, third-party documents, vector database stores) that are dynamically read and executed by an LLM agent.

**Impact**: Silent privilege escalation, dynamic data exfiltration via the user's session context, unauthorized account compromise.

**Controls**: #INPUT SEGREGATION, #PROMPT INJECTION I/O HANDLING, #LEAST MODEL PRIVILEGE

**Vectors**:
- RAG documents with hidden instructions
- Emails/documents with embedded commands
- Images with text-based instructions (OCR)
- Metadata in files
- Web content retrieved by agents

### 2. Sensitive Data Disclosure

**Description**: Model reveals sensitive information in outputs.

**Sources**:
- Training data memorization
- System prompts (if sensitive)
- RAG data (if sensitive)
- Conversation context

**Mitigation**: Data minimization, output filtering, access control

### 3. Hallucinations

**Description**: Model generates factually incorrect information confidently.

**Security Impact**:
- Misinformation leading to wrong decisions
- False sense of confidence in outputs
- Potential for exploitation by attackers

### 4. Shadow AI

**Description**: Employees using consumer AI tools without organizational oversight.

**Risks**:
- Sensitive data sent to external providers
- No security controls on data handling
- Compliance violations
- IP exposure

**Mitigation**: Provide secure alternatives, make risks clear

---

## Ready-Made Model Security

### Deployment Options

| Option | Security Level | Use Case |
|--------|---------------|----------|
| **Closed source, provider-hosted** | Lowest (data leaves your environment) | Most convenient, largest models |
| **Open source, self-hosted** | Highest (data stays in your infrastructure) | Most secure, may not support largest models |
| **Open source, paid hosting** | Medium | Convenient with some control |
| **Self-hosted, your VPC** | High | Good balance of security and capability |

### Provider-Hosted Model Considerations

**Critical Questions**:

1. **Where does the model run?**
   - Vendor's processes vs. your VPC?
   - "Private instance" may refer to API, not model
   - If on vendor's cluster, data leaves your environment in clear text

2. **What are data retention rules?**
   - Court-ordered retention possible
   - Log retention policies vary

3. **What is logged and monitored?**
   - Read the fine print
   - Some vendors allow opt-out (specific licenses only)

4. **Is input used for training?**
   - Vast majority: NO
   - Verify with provider
   - If done secretly, there are ways to detect

**Critical Fact**: Provider-hosted models need your input data in **clear text**. Your sensitive data exists unencrypted outside your infrastructure — same as Google Suite or Microsoft 365.

---

## GenAI Deployment Security Architecture

### Secure RAG Architecture

```
User Input → Input Validation → Retrieval → Context Assembly → Model → Output Filtering → Response
                 ↓                  ↓              ↓              ↓           ↓
           Sanitization        Access        Segregation    System       Sensitive
           Schema check        control       Marking        prompt       data check
           Injection detect    AuthZ         Delimiters     Assembly     PII filter
                                                              ↓
                                                          Model call
                                                          (least priv)
```

### Key Security Controls for RAG

| Control | Purpose |
|---------|---------|
| Input validation | Prevent prompt injection through user input |
| Access control | Ensure retrieval only returns authorized data |
| Input segregation | Clearly mark retrieved data as untrusted |
| Output filtering | Check for sensitive data in responses |
| Least privilege | Model only accesses data user is authorized for |
| Logging | Track all retrieval and generation activity |

### Input Segregation Implementation

**Engineering Implementation**: Structurally separating trusted system instructions from untrusted data blocks within model APIs. For LLMs, this requires encoding inputs via strict structured serialization schemas (e.g., separate JSON schemas or explicit role boundaries like `system`, `user`, and `tool`) rather than simple string concatenations.

---

## Multimodal GenAI Security

### Threats

Instructions can be placed into:
- Text
- Images (OCR, visual encoders)
- Audio
- Video
- Documents with embedded objects

Instructions can be **coordinated across modalities** so the multimodal system interprets and follows them.

### Attack Vectors

**Direct**: Attacker uploads adversarial multimodal input
- Image with hidden text instructions
- Audio with embedded commands
- Document with malicious metadata

**Indirect**: Untrusted multimodal content automatically pulled in
- Product screenshot with hidden text
- Scanned form with instructions
- Social media image with embedded commands

### Defenses

- All prompt injection defenses apply
- Additional: multimodal input scanning
- Image text extraction and validation
- Audio transcription verification
- Document metadata inspection

---

## Seven Layers of GenAI Protection

### Layer 1: Model Alignment
- Training-time alignment (RLHF, fine-tuning)
- System prompts for behavior guidance
- Safety training against jailbreaks

### Layer 2: Prompt Injection I/O Handling
- Input sanitization (Unicode normalization, character filtering)
- Instruction detection (pattern matching, LLM-as-judge)
- Output validation
- Tool selection: Guardrails-AI, LLM Guard, NeMo Guardrails, Rebuff

**Engineering Implementation**: Deploy lightweight, high-speed secondary structural models (classifiers or guardrail layers) directly at system entrance and exit gates to inspect incoming prompts and outgoing generations for malicious instructional payloads.

### Layer 3: Human Oversight
- Approval for critical actions
- Moderate use to avoid fatigue
- Focus on truly critical decisions

### Layer 4: Automated Oversight
- Pattern-based detection
- Anomaly detection
- Action count limits
- Data access monitoring

### Layer 5: User-Based Least Privilege
- Agent gets rights of the user it serves
- Don't exceed user's permissions

### Layer 6: Intent-Based Least Privilege
- Additional restrictions based on task
- Email summarizer: read-only, no send

### Layer 7: Just-in-Time Authorization
- Context-based permissions
- Dynamic permission adjustment
- Ephemeral permissions

---

## GenAI-Specific Testing

### Prompt Injection Testing

```
Test Categories:
├── Direct injection
│   ├── Role-playing attacks
│   ├── Instruction override
│   ├── Encoding tricks
│   ├── Multi-turn manipulation
│   └── Length-based attacks
├── Indirect injection
│   ├── RAG document injection
│   ├── Tool output injection
│   ├── Image/audio injection
│   └── Metadata injection
└── Jailbreak attempts
    ├── Competing objectives
    ├── Out-of-distribution input
    ├── Multi-language attacks
    └── Encoding bypass
```

### Testing Tools

| Tool | Focus | Integration |
|------|-------|-------------|
| Garak | Prompt injection, alignment bypass, data leaks | CI/CD integration |
| PyRIT | Multi-turn security testing | Security review phases |
| Promptfoo | Prompt assertion variance | Development prompt sets |
| Guardrails-AI | Input/output validation | Runtime enforcement |
| LLM Guard | Security toolkit | API gateway |
| NeMo Guardrails | Programmable safety | Application layer |

### Data Leakage Testing

- [ ] Can the model reveal training data?
- [ ] Can system prompts be extracted?
- [ ] Can RAG data be leaked?
- [ ] Can membership inference succeed?

### Output Safety Testing

- [ ] Harmful content generation
- [ ] Bias and discrimination
- [ ] Misinformation
- [ ] Output injection (XSS, SQLi)

### Tool/Action Testing

- [ ] Unauthorized tool usage
- [ ] Privilege escalation
- [ ] Data exfiltration via tools
- [ ] Action chain abuse

---

## Cultural Considerations

### Content Standards Vary by Region

| Region | Approach |
|--------|----------|
| Saudi Arabia | Cultural alignment with Islamic values |
| China | Socialist core values adherence |
| UAE | Dignity, community, societal benefit |
| South Korea | Human-centric, democratic values |
| EU | Risk-based, no ideological constraints |

### Semantic Drift

Words change meaning over time. Events shift morality and ethics. Language-based guards may not address emerging issues in real-time.

**Mitigation**: Continuous red teaming updated with regional concerns + guardrails for additional protection.

### Fair Output Considerations

- Models can only present arguments from training data
- Marginalized communities may be underrepresented
- "Fair" output is subjective
- Consider neutral refusals over verbose explanations

---

## Copyright and IP

### Key Considerations

| Question | Answer |
|----------|--------|
| Is AI output copyrightable? | Generally no in US; varies by jurisdiction |
| Who owns AI-generated code? | Complex — consult legal counsel |
| Training on copyrighted data? | Potentially infringing; fair use defense in some cases |
| Vendor indemnification? | Some vendors offer it (Microsoft, Google Cloud) |

### Mitigation

1. Comprehensive IP audits
2. Clear legal framework and policies
3. Ethical data sourcing
4. Define AI-generated content ownership
5. Confidentiality and trade secret protocols
6. Employee training
7. Compliance monitoring
8. Response planning for IP claims

---

## GenAI Security Checklist

### Pre-Deployment

- [ ] Threat model completed (all GenAI-specific threats)
- [ ] Prompt injection defenses implemented
- [ ] Input/output validation in place
- [ ] Least privilege configured
- [ ] Data minimization applied
- [ ] System prompt secured (not sensitive, not accessible)
- [ ] RAG data access controlled
- [ ] Output filtering for sensitive data
- [ ] Rate limiting configured
- [ ] Logging and monitoring set up
- [ ] Red team testing completed
- [ ] Copyright/IP considerations addressed

### Runtime

- [ ] Continuous validation active
- [ ] Anomaly detection running
- [ ] Usage monitoring in place
- [ ] Incident response plan ready
- [ ] Regular security testing scheduled
- [ ] Provider security posture monitored
- [ ] Compliance requirements tracked

---

## References

- OWASP Top 10 for LLM: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- OWASP GenAI Security Project
- OWASP AI Exchange: https://owaspai.org
- OWASP CHEAT Sheets on Prompt Injection Prevention
- NIST AI 100-2: Generative AI security
- MITRE ATLAS LLM Prompt Injection
- OpenCRE: GenAI security requirements
- Garak: https://github.com/NVIDIA/garak
- PyRIT: https://github.com/Azure/PyRIT
