# AI Security Testing Guide

## Overview

AI systems require specialized testing beyond conventional security testing. The OWASP AI Exchange provides guidance on testing methodologies, tools, and approaches specific to AI/ML systems. This guide includes engineering-focused tool selection and integration strategies.

## Threats to Test For

### Input Threats
- **Prompt Injection** (Direct and Indirect)
- **Evasion Attacks** (adversarial examples)
- **Data Disclosure** (sensitive data in output)
- **Model Inversion** (reconstructing training data)
- **Membership Inference** (detecting training data membership)
- **Model Exfiltration** (copying the model)
- **Resource Exhaustion** (DoS on AI services)

### Development-Time Threats
- **Data Poisoning** (manipulated training data)
- **Model Poisoning** (tampered models)
- **Supply Chain Attacks** (compromised components)

### Runtime Threats
- **Model Tampering**
- **Output Injection** (XSS, SQLi via model output)
- **Input/Augmentation Data Leakage**

---

## Testing Strategies

### 1. AI-Specific Penetration Testing

Conventional penetration testing must be extended with AI-specific attack vectors.

#### General Approach

1. **Reconnaissance**: Understand the AI system architecture
   - What type of model? (GenAI, predictive, heuristic)
   - What data flows in/out?
   - What actions can the model trigger?
   - What are the input/output formats?

2. **Threat Identification**: Use the AI Exchange threat taxonomy
   - Map applicable threats using the decision tree
   - Prioritize based on risk assessment

3. **Attack Simulation**: Attempt identified attacks
   - Start with lowest sophistication attacks
   - Progress to more sophisticated techniques
   - Document all attempts and results

4. **Impact Assessment**: Evaluate successful attack impact
   - Data compromised?
   - Model behavior affected?
   - System availability impacted?

5. **Remediation**: Recommend controls from the AI Exchange catalog

### 2. Adversarial Robustness Testing

Test model resilience against adversarial inputs.

#### For Classification Models

- **White-box testing** (if model access available):
  - FGSM (Fast Gradient Sign Method)
  - PGD (Projected Gradient Descent)
  - CW (Carlini & Wagner) attacks
  
- **Black-box testing**:
  - Query-based attacks
  - Transfer attacks using surrogate models
  - Boundary exploration

#### For Generative AI

- **Prompt injection testing**:
  - Direct injection attempts
  - Indirect injection via data sources
  - Jailbreak attempts
  - Multi-turn manipulation
  
- **Data extraction testing**:
  - Membership inference attempts
  - Training data extraction
  - Model inversion attempts

### 3. Red Teaming

#### Red Teaming for Generative AI

Focus areas:
1. **Jailbreak resistance**: Can alignment be bypassed?
2. **Prompt injection robustness**: Direct and indirect attacks
3. **Output safety**: Harmful content generation
4. **Data leakage**: Sensitive information in outputs
5. **Agentic behavior**: Action escalation, data exfiltration, Lethal Trifecta

#### Red Teaming for Predictive AI

Focus areas:
1. **Adversarial robustness**: Evasion attack resistance
2. **Data poisoning**: Training data manipulation detection
3. **Model extraction**: Can the model be replicated?
4. **Privacy attacks**: Data extraction via model outputs

### 4. Automated Testing Frameworks

#### Continuous Testing

```
Code Commit → Static Analysis → Build → AI Security Tests → Deploy
                                        ├── Adversarial tests
                                        ├── Prompt injection tests
                                        ├── Data leakage tests
                                        └── Robustness tests
```

#### Test Categories

| Category | What to Test | When |
|----------|-------------|------|
| **Pre-deployment** | Model robustness, injection resistance, data leakage | Before each release |
| **Runtime monitoring** | Drift detection, anomaly detection, continuous validation | Ongoing |
| **Periodic** | Full red team, penetration testing | Quarterly/Annually |
| **Event-driven** | After model updates, after incidents | As needed |

---

## Engineering Tool Matrix

This matrix provides actionable patterns for verifying system defense profiles using open-source tools across predictive and generative systems.

### Predictive AI Tools

#### ART (Adversarial Robustness Toolbox)

| Attribute | Detail |
|-----------|--------|
| **Focus** | Evasion perturbations, poisoning resilience |
| **Implementation Strategy** | Run inside CI/CD pipelines before shipping model weights |
| **Key Capabilities** | Calculates evasion perturbations, tests model poisoning resilience, certifiable robustness testing |
| **Framework Support** | TensorFlow, PyTorch, JAX, Scikit-learn |
| **Attack Types** | FGSM, PGD, Carlini-Wagner, DeepFool |
| **Defense Types** | Adversarial training, preprocessing defenses, model hardening |

#### Foolbox

| Attribute | Detail |
|-----------|--------|
| **Focus** | Geometric boundary attacks |
| **Implementation Strategy** | Use to calculate adversarial distribution boundaries |
| **Key Capabilities** | Large collection of adversarial attacks, framework-agnostic |
| **Key Features** | Easy integration with existing models, extensive attack library |

#### TextAttack

| Attribute | Detail |
|-----------|--------|
| **Focus** | NLP adversarial attacks |
| **Key Capabilities** | Text classification attacks, data augmentation, model training support |
| **Use Case** | Testing NLP models against text-based adversarial examples |

### Generative AI Tools

#### Garak

| Attribute | Detail |
|-----------|--------|
| **Focus** | Prompt injection, alignment bypass, data leaks |
| **Implementation Strategy** | Integrate during CI/CD build verification |
| **Key Capabilities** | Automated scanning for LLM vulnerabilities, multiple probe types |
| **Probe Types** | Prompt injection, data leakage, hallucination, denial of service, malware generation |
| **Extensibility** | Plugin system for custom probes |

#### PyRIT (Python Risk Identification Toolkit)

| Attribute | Detail |
|-----------|--------|
| **Focus** | Multi-turn security testing |
| **Implementation Strategy** | Use during security review phases |
| **Key Capabilities** | Simulates multi-turn attacks, automated attack generation, multi-modal testing |
| **Use Cases** | Harm identification, multi-turn conversation attack simulation, Red Team automation |

#### Promptfoo

| Attribute | Detail |
|-----------|--------|
| **Focus** | Prompt assertion variance |
| **Implementation Strategy** | Run during development of system prompt sets |
| **Key Capabilities** | LLM evaluation framework, comparison testing, red team testing |
| **Use Cases** | Prompt performance evaluation, regression testing, security assertion validation |

### Guardrail and Validation Tools

| Tool | Focus | Use Case |
|------|-------|----------|
| **Guardrails-AI** | Input/output validation | Real-time guard definition and checking |
| **LLM Guard** | Prompt injection detection, output filtering | Security toolkit for LLM interactions |
| **NVIDIA NeMo Guardrails** | Programmable safety guardrails | Colang language for custom safety flows |
| **Rebuff** | Prompt injection detection | Detecting manipulation attempts |
| **Langkit** | Text-based telemetry | Input/output validation metrics |

### Tool Selection Guide

```
What type of AI system?
├─ Predictive/Classification
│   ├─ Need adversarial robustness? → ART, Armory, Foolbox
│   ├─ Need NLP testing? → TextAttack
│   └─ Need comprehensive suite? → ART
├─ Generative AI / LLM
│   ├─ Need red teaming? → PyRIT, Garak
│   ├─ Need prompt injection testing? → Prompt Fuzzer, LLM Guard
│   ├─ Need output validation? → Guardrails-AI, NeMo Guardrails
│   └─ Need evaluation framework? → Promptfoo
└─ Agentic AI
    ├─ Need multi-step testing? → PyRIT
    ├─ Need action testing? → Custom framework + PyRIT
    └─ Need injection testing? → Garak + Guardrails
```

---

## Tool Evaluation Reference Matrix

| Category | Tool | Testing Focus | Integration Point | Priority |
|----------|------|--------------|-------------------|----------|
| **Predictive AI** | ART | Evasion perturbations, poisoning resilience | Pre-deployment pipeline | High |
| **Predictive AI** | Foolbox | Geometric boundary attacks | Adversarial distribution calc | Medium |
| **Predictive AI** | TextAttack | NLP adversarial attacks | Development pipeline | Medium |
| **Predictive AI** | Armory | Robustness benchmarks | Evaluation framework | Low |
| **Generative AI** | Garak | Prompt injection, alignment bypass, data leaks | CI/CD integration | High |
| **Generative AI** | PyRIT | Multi-turn security testing | Security review phases | High |
| **Generative AI** | Promptfoo | Prompt assertion variance | Development prompt sets | Medium |
| **Generative AI** | Prompt Fuzzer | Prompt injection fuzzing | CI/CD pipeline | High |
| **Guardrails** | Guardrails-AI | Input/output validation | Runtime enforcement | High |
| **Guardrails** | LLM Guard | Security toolkit | API gateway | High |
| **Guardrails** | NeMo Guardrails | Programmable safety | Application layer | Medium |
| **Guardrails** | Rebuff | Injection detection | Input validation | Medium |

---

## Testing Methodology

### Pre-Deployment Testing Checklist

- [ ] **Prompt Injection**
  - [ ] Direct injection attempts (various strategies)
  - [ ] Indirect injection via RAG/data sources
  - [ ] Jailbreak attempts
  - [ ] Multi-turn manipulation
  - [ ] Multi-modal injection (images, audio, documents)

- [ ] **Data Leakage**
  - [ ] Training data extraction attempts
  - [ ] Membership inference testing
  - [ ] Model inversion attempts
  - [ ] Sensitive data in outputs

- [ ] **Robustness**
  - [ ] Adversarial example testing
  - [ ] Boundary case testing
  - [ ] Out-of-distribution inputs
  - [ ] Input perturbation testing

- [ ] **Access Control**
  - [ ] Privilege escalation attempts
  - [ ] Cross-user data access
  - [ ] Function calling abuse

- [ ] **Availability**
  - [ ] Resource exhaustion testing
  - [ ] Rate limiting effectiveness
  - [ ] Input size limits

- [ ] **Output Safety**
  - [ ] Harmful content generation
  - [ ] Output injection (XSS, SQLi)
  - [ ] Information disclosure

- [ ] **Lethal Trifecta** (Agentic AI)
  - [ ] Untrusted data pipeline exploitation
  - [ ] Privilege escalation via agent actions
  - [ ] Autonomous data transmission attempts

### Runtime Monitoring

- [ ] Continuous validation against test set
- [ ] Drift detection
- [ ] Anomaly detection
- [ ] Usage pattern monitoring
- [ ] Output quality monitoring

### Post-Incident Testing

After any security incident:
1. Reproduce the attack
2. Identify root cause
3. Test fix effectiveness
4. Check for related vulnerabilities
5. Update test suite

---

## Red Teaming Playbook

### Phase 1: Reconnaissance
- Map system architecture
- Identify integration points
- Document data flows
- List action capabilities

### Phase 2: Threat Modeling
- Apply 4-step threat modeling workflow
- Identify Lethal Trifecta conditions
- Prioritize attack vectors

### Phase 3: Attack Execution

#### For GenAI Systems:
1. Direct prompt injection attempts
2. Indirect prompt injection via data sources
3. Jailbreak attempts
4. Multi-turn manipulation
5. Action escalation attempts

#### For Predictive AI Systems:
1. Evasion attacks (white-box and black-box)
2. Data poisoning simulation
3. Model extraction attempts
4. Privacy attacks

#### For Agentic AI Systems:
1. Lethal Trifecta verification
2. Working memory manipulation
3. Inter-agent communication attacks
4. Tool abuse scenarios
5. Privilege escalation chains

### Phase 4: Impact Assessment
- Document successful attacks
- Assess data compromise
- Evaluate business impact
- Determine blast radius

### Phase 5: Remediation Planning
- Recommend controls
- Prioritize fixes
- Plan retesting

---

## Cultural Considerations in Testing

### Culture-Sensitive Alignment

When testing output safety and refusal behaviors:
- Different regions have different content standards
- Test for regional compliance requirements
- Consider semantic drift (words change meaning over time)
- Verify refusal explanations are culturally appropriate

### Multi-Language Testing

- Test in all supported languages
- Language-specific attack vectors
- Translation-based bypass attempts
- Code-switching attacks

---

## Reporting and Documentation

### Test Report Template

```markdown
# AI Security Test Report

## System Under Test
- Model type: [GenAI/Predictive/Agentic]
- Model name/version:
- Deployment environment:
- Test date:

## Scope
- Threats tested:
- Test types performed:
- Tools used:

## Lethal Trifecta Assessment
- Untrusted Data Pipeline: [Present/Not Present]
- Privileged Access: [Present/Not Present]
- Autonomous Transmission: [Present/Not Present]
- Overall Risk Level: [Critical/High/Medium/Low]

## Findings

### Critical
| Finding | Threat | Impact | Evidence | Recommendation |
|---------|--------|--------|----------|----------------|

### High
...

### Medium
...

### Low
...

## Recommendations
1. Immediate actions
2. Short-term improvements
3. Long-term strategy

## Retest Plan
- Timeline:
- Focus areas:
```

---

## References

- OWASP AI Exchange Testing Section: https://owaspai.org/go/testing/
- MITRE ATLAS: https://attack.mitre.org/matrices/enterprise/
- PwnzzAI: AI hacking lab
- NIST AI 100-2: Adversarial attacks and defenses
- ISO/IEC 24029-2: Robustness assessment of neural networks
- ART Documentation: https://adversarial-robustness-toolbox.readthedocs.io/
- Garak Repository: https://github.com/NVIDIA/garak
- PyRIT Repository: https://github.com/Azure/PyRIT
