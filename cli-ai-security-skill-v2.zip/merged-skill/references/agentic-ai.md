# Agentic AI Security Guide

## Overview

Agentic AI represents a new paradigm where AI systems can take actions, operate autonomously, and communicate with other agents. This introduces unique security challenges beyond traditional AI systems, including the **Lethal Trifecta** — a catastrophic failure path that must be analyzed and mitigated.

**Key Principle**: Agentic AI systems are still software systems and AI systems — everything in the AI Exchange applies, but additional considerations are necessary.

---

## What is Agentic AI?

An example: A set of voice assistants that can control your heating, send emails, and even invite more assistants into the conversation. That's powerful — but you'd want it to check with you before sending a thousand emails.

### Four Typical Properties

| Property | Description | Security Implication |
|----------|-------------|---------------------|
| **Action** | Agents invoke functions (send email, execute code) | LEAST MODEL PRIVILEGE is critical |
| **Autonomous** | Agents can trigger each other | OVERSIGHT is essential; working memory is attack vector |
| **Complex** | Emergent behavior | Hard to predict security implications |
| **Multi-system** | Mix of systems and interfaces | Access control assigned via instructions (vulnerable to prompt injection) |

---

## Key Security Implications

### 1. Action Capability

Agents don't just chat — they invoke functions.

**Risk**: If a model is manipulated (via prompt injection, etc.), it can trigger harmful actions.

**Key Control**: #LEAST MODEL PRIVILEGE
- Minimize what each agent can do
- Separate agents by permission level
- Don't give general-purpose agents all permissions

### 2. Autonomous Behavior

Agents can trigger each other, enabling autonomous responses.

**Risks**:
- Working memory becomes an attack vector (where state and plan live)
- Chain of agents can amplify single compromise
- Hard to maintain oversight of autonomous flows

**Key Controls**: #OVERSIGHT, working memory protection

### 3. Emergent Complexity

Agentic behavior is emergent — not explicitly programmed.

**Risks**:
- Unexpected security vulnerabilities
- Hard to predict all failure modes
- Testing is more challenging

### 4. Multi-System Architecture

Developers tend to assign access control responsibilities to AI via instructions.

**Risk**: This opens the door for manipulation through prompt injection.

**Key Principle**: **Don't assign access control responsibility to GenAI models/agents.** Build access control into your architecture.

---

## The Lethal Trifecta

For data exfiltration in agentic AI, three conditions must be met for **catastrophic failure**:

```
┌─────────────────────────────────────────────────────────────┐
│  1. UNTRUSTED DATA PIPELINE                                │
│     Condition: Attacker controls an input vector that       │
│     automatically loads into an LLM context window           │
│     (web scrapers, user forms, emails, resumes)              │
│     triggering Indirect Prompt Injection                    │
│                                                             │
│  2. PRIVILEGED ACCESS                                      │
│     Condition: Executing model or agent holds authenticated │
│     programmatic access (APIs, read/write permissions)     │
│     to sensitive backend databases, corporate secrets,      │
│     or transactional environments                           │
│                                                             │
│  3. AUTONOMOUS TRANSMISSION                                │
│     Condition: Model possesses an open outbound channel    │
│     or connected action (mail invocation, webhook           │
│     execution, dynamic URL rendering) capable of pushing    │
│     structured data out of trust boundary                   │
│                                                             │
│  ALL THREE = CATASTROPHIC DATA EXFILTRATION               │
│  Missing ANY ONE = Attack Fails                           │
└─────────────────────────────────────────────────────────────┘
```

### Breaking the Trifecta

| Condition | Defense Strategies |
|-----------|-------------------|
| **Break Data** | Input segregation, data validation, source verification, sanitize RAG data |
| **Break Access** | Least privilege, network segmentation, user-scoped permissions, no agent-native permissions |
| **Break Send** | Egress filtering, action approval, output monitoring, sandboxing |

### Risk Level Based on Trifecta

| Trifecta Status | Risk Level | Action |
|----------------|------------|--------|
| All three present | **CRITICAL** | Must break at least one condition before deployment |
| Two present | **HIGH** | Implement controls to break or monitor the third condition |
| One present | **MEDIUM** | Document and monitor for escalation |
| None present | **LOW** | Standard risk management |

---

## Core Threats in Agentic AI

### 1. Prompt Injection (Primary Threat)

**Direct Prompt Injection**: User manipulates agent through crafted input.

**Indirect Prompt Injection**: Malicious instructions in data the agent accesses.

**Impact in Agentic Context**:
- Change commands the agent executes
- Escalate privileges
- Access unauthorized data
- Trigger harmful actions

**Why Critical**: Prompt injection is the key threat in most agentic AI systems.

### 2. Privilege Escalation

Agents deployed with their own permissions create escalation vectors:
- **Confused Deputy**: Agent acts on behalf of attacker with its own privileges
- **Permission Inheritance**: Sub-agents inherit excessive permissions
- **Cross-Agent Escalation**: Compromise one agent to access others

### 3. Working Memory Attacks

Agents maintain state in working memory:
- Attackers can manipulate memory through prompt injection
- Compromised state leads to compromised actions
- Memory persistence allows attacks across sessions

### 4. Inter-Agent Communication

Communication between agents (e.g., MCP protocol):
- Can be intercepted or manipulated
- May carry injected instructions
- Trust boundaries between agents need definition

### 5. Tool/API Abuse

Agents call external tools and APIs:
- Each tool is an attack surface
- Tool outputs may contain injected instructions
- Chain of tool calls can amplify impact

---

## Seven Layers of Prompt Injection Protection

Defense in depth for prompt injection in agentic systems:

### Layer 1: Model Alignment
Tell models to behave and resist manipulation through training and system prompts.

**Limitation**: Models remain easy to mislead; additional controls required.

### Layer 2: Prompt Injection I/O Handling
Invest in sanitizing, filtering, and detecting prompt injection.

**Limitation**: New bypass techniques continue to appear; detection is difficult with false positives/negatives.

**Key Insight**: Assume prompt injection can succeed despite alignment and I/O handling. The remaining layers are about blast radius control.

### Layer 3: Human Oversight
Human-in-the-loop approves critical actions.

**Limitation**: Costly, delays flows, humans suffer approval fatigue, may lack expertise.

**Best Practice**: Apply moderately — only for truly critical actions.

### Layer 4: Automated Oversight
Logic to check for suspicious activity in context.

**Limitation**: Reactive — acts only after behavior emerges. Preventive controls are more effective.

**Examples**: Email summarizer trying to send 1000 emails; agent accessing unusual data.

### Layer 5: User-Based Least Privilege
Give agent the rights of the individual being served.

**Limitation**: Users often have more permissions than agent needs.

**Example**: Email summarizer should only access that user's emails.

### Layer 6: Intent-Based Least Privilege
Give agent rights required for its specific task, in addition to user-based rights.

**Limitation**: Intent not always known in advance; multiple agents may need different privilege sets.

**Example**: Email summarizer should only read emails, not send them.

### Layer 7: Just-in-Time Authorization
Give each agent only rights required at that moment, based on context.

**Context Sources**:
- Task assignment (e.g., "review merge request")
- Data entering the flow (untrusted data triggers reduced permissions)

**Example**: Orchestrating agent has no direct mail server access; summarizer agent has no rights.

---

## Least Model Privilege Strategies

### Strategy 1: Harden Based on General Intent
Minimize permissions based on reasonably foreseeable use cases.

### Strategy 2: Harden Based on Prompt Intent
Use LLM to interpret prompt intent and set permissions dynamically.

### Strategy 3: Harden Based on Role Assignment
When agent is assigned a task, minimize to that role's permissions.

### Strategy 4: Harden Based on Risk Elevation
Increase restrictions when untrusted data enters the flow:
- Disable actions that send data out
- Reduce available tools
- Require additional approval

### Strategy 5: Downgrade Subagents
Inter-agent calls include reduced permission sets:
- Hand-down mechanism outside the LLM
- E.g., email agent calls summarizer → summarizer gets no email access

### Strategy 6: Hardening as Incident Response
Based on suspicion level, automatically or manually harden the flow:
- Reduce blast radius
- Don't fully stop (to limit interference)

### Strategy 7: Ephemeral Permissions
Temporary permissions that expire after task completion:
- Prevents long-lived permission abuse
- Temporal blast radius control

---

## Architecture Best Practices

### 1. Don't Rely on AI for Access Control

```
❌ BAD: "You can only access emails if the user allows it"
   (Instruction-based access control - vulnerable to prompt injection)

✅ GOOD: Access control enforced in application layer
   (Agent API only returns authorized data regardless of prompt)
```

### 2. Separate Orchestration from Execution

```
Orchestrator Agent
    ├── Determines what to do
    ├── Has NO direct tool access
    └── Delegates to specialized agents

Specialized Agents
    ├── Have minimal, task-specific permissions
    ├── Execute specific actions
    └── Report back to orchestrator
```

### 3. Defense in Depth

```
Input → Sanitization → Validation → Agent → Oversight → Action → Output Filter
         ↓              ↓            ↓         ↓          ↓          ↓
      Inject check   Schema check  LLM check  Pattern   Rate limit  XSS check
      Unicode norm   Type check    Model check  check    Egress filter
```

### 4. Zero Trust for Agents

- Every agent interaction authenticated
- Every action authorized for current context
- Assume any agent could be compromised
- Verify all inputs from other agents
- Log everything

### 5. Circuit Breakers

Implement automatic circuit breakers:
- Action count limits per time period
- Resource usage limits
- Anomaly-triggered lockdowns
- Manual kill switches

### 6. Lethal Trifecta Mitigation Architecture

For systems where all three Trifecta conditions exist:

```
┌────────────────────────────────────────────────────────────────┐
│                    LETHAL TRIFECTA MITIGATION                   │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  DATA PIPELINE          PRIVILEGED ACCESS     TRANSMISSION    │
│  ─────────────          ────────────────      ────────────     │
│  • Input segregation   • Least privilege     • Egress filter  │
│  • Data validation     • User-scoped perm    • Action approv  │
│  • Source verification • No agent-native per • Sandboxing     │
│  • RAG sanitization    • Network segment.     • Output monitor │
│                                                                │
│  BREAK ANY ONE CONDITION = Attack Fails                       │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## Testing Agentic AI

### Red Teaming Scenarios

1. **Privilege Escalation**
   - Can an agent access data beyond its scope?
   - Can prompt injection lead to action escalation?

2. **Data Exfiltration / Lethal Trifecta**
   - Can the lethal trifecta be achieved?
   - Can data be sent out via agent actions?
   - Test each condition independently

3. **Agent Manipulation**
   - Can indirect prompt injection control agent behavior?
   - Can working memory be manipulated?

4. **Chain Reactions**
   - Can compromising one agent affect others?
   - Can autonomous loops be triggered?

5. **Tool Abuse**
   - Can tools be called with malicious parameters?
   - Can tool outputs inject instructions?

### Testing Tools

| Tool | Agentic Relevance |
|------|------------------|
| PyRIT | Multi-step attack simulation |
| Garak | LLM vulnerability scanning |
| Custom frameworks | Agent-specific testing |

### Lethal Trifecta Test Cases

| Test ID | Condition Tested | Test Scenario | Expected Result |
|---------|------------------|----------------|-----------------|
| LT-01 | Untrusted Data | Inject malicious instructions in RAG data | System detects/ignores injection |
| LT-02 | Privileged Access | Agent attempts to access unauthorized data | Access denied by architecture |
| LT-03 | Autonomous Transmission | Agent attempts to send data externally | Transmission blocked/monitored |
| LT-04 | Combined | Full Trifecta attack | At least one condition prevented |

---

## Monitoring and Detection

### What to Monitor

| Signal | Indicator |
|--------|-----------|
| **Action patterns** | Unusual sequences or frequencies |
| **Data access patterns** | Accessing unusual data volumes or types |
| **Communication patterns** | Unusual inter-agent communication |
| **Permission usage** | Using rarely-needed permissions |
| **Error patterns** | Unusual error rates or types |
| **Resource usage** | Unusual compute or API consumption |
| **Lethal Trifecta indicators** | Untrusted data + privileged access + outbound activity |

### Alerting Rules

- Agent attempts action outside normal pattern
- Agent accesses data it rarely accesses
- Unusual spike in API calls
- Agent communication with unknown entities
- Privilege escalation attempts
- Data egress to unusual destinations
- **CRITICAL**: Simultaneous indicators of all three Trifecta conditions

---

## Incident Response for Agentic AI

### Immediate Actions

1. **Isolate**: Stop the agent or restrict its permissions
2. **Assess**: Determine what actions were taken
3. **Contain**: Prevent further unauthorized actions
4. **Investigate**: Trace the attack path
5. **Remediate**: Fix vulnerabilities
6. **Recover**: Restore normal operations

### Post-Incident

1. Update agent permissions
2. Add new detection rules
3. Patch vulnerabilities
4. Review and update threat model
5. Update testing scenarios
6. **Review Lethal Trifecta conditions**: Were all three exploited?

---

## References

- OWASP Agentic AI Security Top 10
- OWASP GenAI Security Project — Agentic AI Threats and Mitigations
- CSA + AI Exchange: Agentic AI Red Teaming Guide
- Microsoft Pulse Report on Agentic Security
- Chip Huyen: Agentic AI Architecture
- Simon Willison: Lethal Trifecta concept
- A Novel Zero-Trust Identity Framework for Agentic AI
