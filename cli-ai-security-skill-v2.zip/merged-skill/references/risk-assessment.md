# AI Risk Assessment Methodology

## Overview

The OWASP AI Exchange provides a structured risk assessment methodology specifically designed for AI systems. Risk assessment determines which threats apply to a specific system, their severity, and appropriate controls.

## Risk Management Framework

Organizations classify risks into: Strategic, Operational, Financial, Compliance, Reputation, Technology, Environmental, Social, and Governance (ESG).

A threat becomes a **risk** when it exploits one or more vulnerabilities.

### The Four Key Steps

1. **Identifying Risks** — Recognizing potential risks
2. **Evaluating Risks** — Estimating likelihood and impact
3. **Risk Treatment** — Choosing mitigation strategies
4. **Risk Communication & Monitoring** — Ongoing stakeholder communication

Plus: **Repeat regularly** and when changes warrant it.

---

## Step 1: Identifying Risks — Decision Tree / Threat Model

Use the decision tree to identify applicable threats for a specific AI system.

### Decision Tree Questions

#### Q1: What type of AI system?

```
Is the model GenAI (e.g., LLM)?
├─ YES → Consider:
│   ├─ Direct prompt injection (if attacker can provide input)
│   └─ Indirect prompt injection (if system inserts untrusted data)
└─ NO → Skip prompt injection threats

Does the model perform classification?
├─ YES → Consider evasion attacks
│   └─ Can adversary influence input? → Evasion is applicable
└─ NO → Skip evasion
```

#### Q2: Who trains/finetunes the model?

```
Do you train your own model?
├─ YES → Consider:
│   ├─ Data poisoning
│   ├─ Direct development-time model poisoning
│   ├─ Disclosure in output (if training data is sensitive)
│   ├─ Model inversion / Membership inference
│   ├─ Direct training data leak
│   ├─ Direct development-time model leak
│   └─ Model exfiltration (if model is IP)
└─ NO (using ready-made model) → Consider:
    ├─ Supply chain model poisoning
    ├─ Supply chain data poisoning
    └─ Supplier responsibility for training data controls
```

#### Q3: Does the system augment model input?

```
Does the system insert data into model input (RAG, system prompts, memory)?
├─ YES → Consider:
│   ├─ Augmentation data manipulation
│   └─ Direct augmentation data leak
└─ NO → Skip augmentation threats
```

#### Q4: Who runs the model?

```
Does a supplier run the model?
├─ YES → Supplier responsible for runtime model poisoning/leak
│   └─ Verify through supply chain management
└─ You run the model → Consider:
    ├─ Direct runtime model poisoning
    └─ Direct runtime model leak
```

#### Q5: Is the input data sensitive?

```
Is input data sensitive?
├─ YES → Consider input data leak
│   └─ Especially if model runs externally
└─ NO → Lower priority for input data protection
```

#### Q6: Does the model produce text output?

```
Does the model create text output?
├─ YES → Consider output contains conventional injection
│   └─ If output is interpreted downstream (browser, database)
└─ NO → Skip output injection
```

#### Q7: Can the model trigger actions?

```
Can the model trigger actions (API calls, emails, physical actions)?
├─ YES → Evaluate impact of actions
│   ├─ Can actions send data? → Check for "Lethal Trifecta"
│   ├─ Can actions access sensitive data? → Increased impact
│   └─ Physical actions? → Safety implications
└─ NO → Standard impact assessment
```

#### ALWAYS CONSIDER:
- AI resource exhaustion
- Generic runtime security threats
- Conventional development/supply chain threats

---

## Step 2: Evaluating Risks — Likelihood and Impact

### Estimating Likelihood

Factors to consider:

| Factor | Description | Standard |
|--------|-------------|----------|
| **Opportunity** | Attacker access to the system | OWASP FAIR |
| **Risk of getting caught** | Deterrence factor | FAIR |
| **Capabilities/tools/budget** | Attacker resources | ISO 27005, OWASP, FAIR |
| **Susceptibility** | System vulnerability to attack | ISO 27005, FAIR |
| **Motive** | Why would someone attack? | OWASP, FAIR, ISO 27005 |
| **Number of potential attackers** | Attack surface size | OWASP |
| **Incident/attempt data** | Historical evidence | ISO 27005 |

**Examples**:
- Public-facing classification model → High likelihood of evasion attempts
- Financial AI system → High motive for data poisoning
- Widely deployed LLM → High number of potential attackers
- Unique model architecture → Lower susceptibility to transfer attacks

### Evaluating Impact

Impact categories:

| Category | Examples |
|----------|----------|
| **Financial** | Fraud losses, remediation costs, fines |
| **Operational** | Service disruption, business continuity |
| **Reputational** | Brand damage, loss of trust |
| **Legal/Compliance** | Regulatory penalties, lawsuits |
| **Safety** | Physical harm (medical AI, autonomous systems) |
| **Competitive** | IP theft, competitive disadvantage |
| **Customer** | Dissatisfaction, churn |
| **Employee** | Reduced morale, productivity loss |

**Impact Assessment by Threat**:

| Threat | Potential Impact |
|--------|-----------------|
| Prompt injection | Wrong decisions, business loss, misbehavior undetected, reputational damage, legal issues, safety issues |
| Evasion | Wrong classifications, bypassed security (spam, fraud) |
| Data poisoning | Persistent wrong behavior, undetected manipulation |
| Data disclosure | Fines, legal fees, reputation damage |
| Model theft | Investment devalued, competitive advantage lost |
| Resource exhaustion | Unavailability, high costs, business continuity |
| Input data leak | Privacy violations, sensitive data exposure |

### Risk Prioritization

Use a **risk heat map** to categorize by likelihood × impact:

```
                    IMPACT
              Low    Medium    High    Critical
         ┌─────┬─────┬─────┬─────────┐
High     │ Med │ High│Crit │ Crit    │
         ├─────┼─────┼─────┼─────────┤
L        │ Low │ Med │ High│ Crit    │
I        ├─────┼─────┼─────┼─────────┤
K  Medium│ Low │ Med │ High│ High    │
E        ├─────┼─────┼─────┼─────────┤
L  Low   │ Low │ Low │ Med │ High    │
I        ├─────┼─────┼─────┼─────────┤
HOOD Low  │ Low │ Low │ Low │ Med     │
         └─────┴─────┴─────┴─────────┘
```

Prioritize: Critical → High → Medium → Low

---

## Step 3: Risk Treatment

### Treatment Strategies

| Strategy | When to Use | Description |
|----------|-------------|-------------|
| **Mitigate** | Risk can be reduced cost-effectively | Implement controls to reduce likelihood or impact |
| **Transfer** | Risk can be shifted | Insurance, supplier contracts, warranties |
| **Avoid** | Risk is unacceptable and cannot be mitigated | Remove the AI component or capability |
| **Accept** | Risk is within tolerance | Document and monitor |

### Control Selection Process

For each risk:

1. **Can the threat be eliminated?** → Avoid
2. **Can it be transferred?** → Transfer (supplier, insurance)
3. **Can likelihood be reduced?** → Preventive controls
4. **Can impact be reduced?** → Mitigating controls
5. **Is residual risk acceptable?** → Accept or iterate

### Defense in Depth

No single control is sufficient. Combine multiple layers:

```
Layer 1: Governance (prevent organizational gaps)
Layer 2: Data limitation (reduce what can be compromised)
Layer 3: Prevention (block attacks)
Layer 4: Detection (identify ongoing attacks)
Layer 5: Mitigation (limit impact)
Layer 6: Recovery (restore after attack)
```

---

## Step 4: Risk Communication & Monitoring

### Risk Register

Maintain a comprehensive list of risks with attributes:
- Risk description
- Severity (likelihood × impact)
- Treatment plan
- Ownership
- Status
- Review date

### Continuous Monitoring

- Regular risk reassessment
- Monitor threat landscape changes
- Track control effectiveness
- Update risk register
- Communicate changes to stakeholders

### Key Performance Indicators

- Number of identified threats vs. addressed threats
- Control implementation coverage
- Time to detect anomalies
- Time to respond to incidents
- Residual risk levels over time

---

## The Lethal Trifecta Analysis

For agentic AI systems, perform this specialized analysis to identify catastrophic failure paths.

### The Lethal Trifecta Defined

```
┌─────────────────────────────────────────────────────────────┐
│  1. UNTRUSTED DATA PIPELINE                                │
│     Condition: Attacker controls an input vector that       │
│     automatically loads into an LLM context window           │
│     (web scrapers, user forms, emails, resumes)              │
│                                                             │
│  2. PRIVILEGED ACCESS                                      │
│     Condition: Executing model or agent holds authenticated │
│     programmatic access to sensitive backend systems        │
│     (APIs, databases, transactional environments)           │
│                                                             │
│  3. AUTONOMOUS TRANSMISSION                                │
│     Condition: Model possesses an open outbound channel     │
│     capable of pushing data out of trust boundary           │
│     (email, webhooks, URL rendering)                        │
│                                                             │
│  ALL THREE PRESENT = CATASTROPHIC DATA EXFILTRATION       │
│  MISSING ANY ONE = Attack Fails                           │
└─────────────────────────────────────────────────────────────┘
```

### Lethal Trifecta Assessment Checklist

For each AI system capable of taking actions:

| Condition | Question | YES/NO |
|----------|---------|--------|
| **Untrusted Data Pipeline** | Does the system accept external data (RAG, user input, web scraping)? | |
| | Can attacker control what data enters the model context? | |
| | Is data inserted without user consent/awareness? | |
| **Privileged Access** | Does the model/agent have access to sensitive systems? | |
| | Can the model access databases, APIs, or files beyond its immediate task? | |
| | Are permissions granted based on model/agent identity rather than user? | |
| **Autonomous Transmission** | Can the model/agent send data externally? | |
| | Are there email, webhook, or file creation capabilities? | |
| | Can data be pushed without explicit user approval? | |

### Breaking the Trifecta

If all three conditions are present, implement controls to break at least one:

| Condition | Defense Strategies |
|-----------|-------------------|
| **Break Data** | Input segregation, data validation, source verification, sanitize RAG data |
| **Break Access** | Least privilege, network segmentation, user-scoped permissions, no agent-native permissions |
| **Break Send** | Egress filtering, action approval, output monitoring, sandboxing |

### Risk Level Based on Trifecta

| Trifecta Status | Risk Level | Action |
|----------------|------------|--------|
| All three present | **CRITICAL** | Must break at least one condition before deployment |
| Two present | **HIGH** | Implement controls to break or monitor the third condition |
| One present | **MEDIUM** | Document and monitor for escalation |
| None present | **LOW** | Standard risk management |

---

## 4-Step Threat Modeling Workflow

This systematic process converts theoretical failure modes into prioritized architectural controls.

### Step 1: Define System Architecture and Asset Boundaries

Identify every operational component of the machine learning system:

**Training Data Pools:**
- Are datasets generated in-house?
- Scraped from public web paths?
- Imported from external vendors?

**Model Execution Boundaries:**
- External cloud API (third-party managed)?
- Internally hosted using open-source weights via Docker/K8s?
- Hybrid deployment?

**Context Aggregators:**
- Vector database for RAG?
- Dynamic Retrieval-Augmented Generation (RAG)?
- Static system prompts only?

### Step 2: Trace the Lethal Trifecta Vector

Examine interaction pathways for execution hazards:

**Outbound Communication Check:**
- Verify whether model output directly executes system shell tasks
- Format local database queries
- Generate customer-facing files

**Network Transmission Check:**
- Inspect outbound communication vectors
- Confirm if model can trigger network hooks
- Determine if model can transmit information beyond internal network segment

### Step 3: Map System Assets to Vulnerability Matrix

Consult the threat evaluation catalog to determine applicable risks based on architecture:

| Architecture Type | Primary Threats to Consider |
|------------------|---------------------------|
| Classification pipeline (transaction scoring) | Test-time evasion anomalies |
| User-facing chatbot with RAG context | Indirect prompt injections, I/O data leakage |
| Agentic system with tool access | Lethal Trifecta, privilege escalation |
| Multi-modal system | Cross-modal prompt injection, output manipulation |
| Self-trained model on sensitive data | Data poisoning, membership inference, model inversion |

### Step 4: Establish Continuous Validation Infrastructure

Integrate chosen mitigation controls directly into infrastructure build specs:

1. Deploy automated adversarial scanning checks into validation cycles
2. Run automated tests before deploying updated weights into live serving setups
3. Establish rollback procedures for model updates
4. Set up continuous monitoring for model behavior drift

---

## Risk Assessment Templates

See `examples/risk-assessment-template.md` for ready-to-use templates.

---

## Standards References

| Standard | Focus | Gap Coverage |
|----------|-------|-------------|
| ISO/IEC 27005 | Security risk management | Covers process; lacks AI-specific threats |
| ISO/IEC 23894 | AI risk management | Refers to ISO 24028 for threats (less comprehensive than AI Exchange) |
| NIST AI RMF | AI risk management | Comprehensive AI-specific guidance |
| FAIR | Factor Analysis for Information Risk | Quantitative risk analysis |
| ETSI | Threat/Vulnerability/Risk Analysis | Method and pro forma |
| ISO/IEC 27563:2023 | AI use cases security & privacy | 132 use cases, 22 domains, security/privacy concern ratings |
| MITRE ATLAS | Adversarial tactics | Specific AI attack techniques |
| ISO/IEC 27090 | AI Security | AI Exchange provides technical foundation |
| ISO/IEC 27091 | AI Privacy | AI Exchange provides technical foundation |

---

## Quick Reference: Threat Applicability

| Threat | Condition for Applicability |
|--------|---------------------------|
| Direct prompt injection | Model is GenAI + attacker can provide input |
| Indirect prompt injection | Model is GenAI + system inserts untrusted data |
| Evasion | Model performs classification + adversary can influence input |
| Data poisoning | You train your own model |
| Supply chain model poisoning | Model is from a supplier |
| Supply chain data poisoning | Data is from a supplier |
| Augmentation data manipulation | System inserts data into model input |
| Disclosure in output | You train model + training data is sensitive |
| Model inversion | You train model + susceptible to inversion |
| Membership inference | Membership in training data is sensitive |
| Model exfiltration | Model is IP or susceptible to evasion |
| AI resource exhaustion | Always possible |
| Input data leak | Input data is sensitive |
| Output injection | Output text is interpreted downstream |
| Direct runtime model poisoning | Always theoretically possible |
| Direct runtime model leak | Model is valuable IP |
| Lethal Trifecta | Agentic AI + untrusted data + privileged access + autonomous transmission |
