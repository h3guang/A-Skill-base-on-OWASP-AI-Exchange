name: cli-ai-security-skill
description: Comprehensive AI/ML security assessment and implementation skill based on OWASP AI Exchange framework. Covers threat modeling, risk assessment, security controls, testing, privacy, and governance for all AI systems (Generative AI, Predictive AI, Agentic AI). Features the G.U.A.R.D. governance framework, Lethal Trifecta methodology, and engineering-focused tool matrix.
version: 2.0.0
author: AI Security Expert
tags: [ai-security, ml-security, owasp, threat-modeling, risk-assessment, genai-security, agentic-ai, guard-framework, lethal-trifecta]
---

# AI Security Assessment Skill v2.0.0

## Overview

This skill provides comprehensive AI/ML system security assessment capabilities based on the OWASP AI Exchange framework — the world's most comprehensive AI security guide with 300+ pages of practical guidance. This **v2.0.0** merged edition integrates the original comprehensive Coze version with the engineering-focused Gemini version, providing both academic rigor and production-ready implementation guidance.

**New in v2.0.0:**
- G.U.A.R.D. Governance Framework — 5-stage AI security lifecycle
- Lethal Trifecta Methodology — catastrophic failure path analysis
- Engineering Tool Matrix — production-ready testing tools (ART, Foolbox, Garak, PyRIT, Promptfoo)
- 4-Step Threat Modeling Workflow — systematic security engineering process
- Enhanced threat descriptions with Mechanism/Impact/Controls format

## When to Use This Skill

Use this skill when:
- Conducting AI/ML system security assessments
- Performing threat modeling for AI systems
- Evaluating AI-specific security risks
- Implementing security controls for AI systems
- Reviewing AI system architecture for security
- Preparing for AI security compliance (EU AI Act, ISO/IEC 27090, ISO/IEC 27091)
- Conducting AI red teaming or penetration testing
- Assessing AI supply chain security
- Evaluating AI privacy and data protection
- Providing AI security training or consulting

## Core Capabilities

1. **Threat Identification**: Identify AI-specific threats using the comprehensive threat taxonomy with engineering-focused descriptions
2. **Risk Assessment**: Perform AI-specific risk analysis using structured methodologies including Lethal Trifecta analysis
3. **Control Selection**: Recommend appropriate security controls based on threats and context with implementation parameters
4. **Testing Guidance**: Provide AI security testing approaches and tool recommendations with production integration strategies
5. **Compliance Mapping**: Map security controls to regulatory requirements (ISO/IEC 27090, ISO/IEC 27091, EU AI Act)
6. **Architecture Review**: Evaluate AI system designs for security considerations

## Knowledge Base Structure

### References

- `references/framework-overview.md` - High-level framework understanding with Core Tenets and standards mapping
- `references/threat-taxonomy.md` - Complete AI threat classification with Mechanism/Impact/Controls format
- `references/controls-catalog.md` - Security controls directory with implementation parameters
- `references/risk-assessment.md` - Risk assessment methodology with Lethal Trifecta and 4-step workflow
- `references/testing-guide.md` - AI security testing approaches with engineering tool matrix
- `references/privacy-guide.md` - AI privacy considerations
- `references/governance-guide.md` - AI governance framework with G.U.A.R.D. implementation
- `references/agentic-ai.md` - Agentic AI specific security with Lethal Trifecta integration
- `references/genai-security.md` - Generative AI specific security

### Examples

- `examples/threat-model-template.md` - Threat modeling template with 4-step workflow
- `examples/risk-assessment-template.md` - Risk assessment template with Lethal Trifecta section
- `examples/security-checklist.md` - Security assessment checklist (150+ items)

## Key Frameworks and Methodologies

### G.U.A.R.D. Governance Framework

The G.U.A.R.D. framework provides a 5-stage lifecycle for operationalizing AI security:

```
┌─────────┐    ┌───────────┐    ┌────────┐    ┌────────┐    ┌────────────┐
│ GOVERN  │───▶│ UNDERSTAND│───▶│ ADAPT  │───▶│ REDUCE │───▶│ DEMONSTRATE│
└─────────┘    └───────────┘    └────────┘    └────────┘    └────────────┘
```

1. **GOVERN**: Maintain centralized AI inventory, perform business/privacy impact analyses, assign strict asset accountabilities, cross-reference with legal frameworks
2. **UNDERSTAND**: Map system architectures against decision trees to deduce which theoretical threats translate into actual technical risk
3. **ADAPT**: Integrate AI-specific data structures (weights, training corpuses, embeddings) into ISMS and SDLC
4. **REDUCE**: Enforce data minimization, obfuscate training records, manage least privileges, institute downstream guardrails
5. **DEMONSTRATE**: Generate cryptographic lineage documentation, validation audit trails, automated red-teaming telemetry

### The Lethal Trifecta

For data exfiltration in agentic AI, three conditions must be met for catastrophic failure:

```
┌─────────────────────────────────────────────────────────────┐
│  1. UNTRUSTED DATA PIPELINE                                │
│     Attacker controls input that auto-loads into LLM context│
│                                                             │
│  2. PRIVILEGED ACCESS                                       │
│     Model/agent has authenticated access to sensitive data  │
│                                                             │
│  3. AUTONOMOUS TRANSMISSION                                │
│     Model can push data out via email, webhooks, etc.       │
│                                                             │
│  ALL THREE = CATASTROPHIC DATA EXFILTRATION               │
│  Missing ANY ONE = Attack Fails                           │
└─────────────────────────────────────────────────────────────┘
```

### Core Tenets of AI Security Assurance

1. **Inductive Nature Risks**: ML models define behavior based on statistical data distributions — being wrong is an intrinsic property
2. **Fluidity of Boundaries**: LLMs treat system instructions and data interchangeably within context windows, breaking classic trust boundaries
3. **Zero Model Trust**: Controls must assume any model can be manipulated, fooled, or induced to leak — focus on hardening AND blast radius limitation

## Execution Flow

### 1. Understand the AI System

First, gather information about the AI system:
- **AI Type**: Generative AI (LLM), Predictive AI, Agentic AI, or heuristic system?
- **Deployment Model**: Self-trained, fine-tuned, or ready-made model?
- **Hosting**: Self-hosted, provider-hosted, or hybrid?
- **Data Sources**: Training data, RAG/augmentation data, input data?
- **Capabilities**: Classification, generation, action execution, multi-agent?
- **Integration Points**: APIs, databases, external services?

### 2. Identify Applicable Threats

Use the threat taxonomy to identify relevant threats:

**Model Behavior Integrity Threats:**
- Direct prompt injection (GenAI only)
- Indirect prompt injection (GenAI with untrusted data)
- Evasion attacks (classification tasks)
- Model poisoning (runtime/development)
- Data poisoning (training data)
- Supply chain model poisoning
- Augmentation data manipulation

**Data Confidentiality Threats:**
- Sensitive data disclosure in output
- Model inversion attacks
- Membership inference
- Training data leakage
- Augmentation data leakage
- Input data leakage

**Model Confidentiality Threats:**
- Model exfiltration
- Direct runtime model leak
- Direct development-time model leak

**Availability Threats:**
- AI resource exhaustion

**Conventional Security Threats:**
- Output contains conventional injection
- Generic runtime security threats
- Development environment threats

### 3. Assess Risk Levels

For each identified threat:
1. **Likelihood Assessment**: Consider attacker access, capabilities, motivation, system susceptibility
2. **Impact Assessment**: Evaluate potential harm (financial, operational, reputational, legal, safety)
3. **Risk Prioritization**: Use risk heat map to prioritize
4. **Lethal Trifecta Check**: For agentic systems, verify if all three conditions exist

### 4. Recommend Controls

Select appropriate controls from the control catalog with implementation parameters:

**Governance Controls:**
- AI Program establishment
- Security Program integration
- Secure Development Program
- Compliance checking
- Security education

**Data Limitation Controls:**
- Data minimization with differential privacy
- Allowed data specification
- Short retention
- Training data obfuscation

**Behavior Limitation Controls:**
- Oversight mechanisms (human and automated)
- Least model privilege
- Model alignment
- AI transparency
- Continuous validation
- Explainability
- Unwanted bias testing

**Input Threat Controls:**
- Monitor use
- Rate limiting
- Model access control
- Anomalous input handling
- Prompt injection I/O handling
- Input segregation

**Development-time Controls:**
- Development environment security
- Data segregation
- Confidential compute
- Federated learning
- Supply chain management
- Model ensemble
- Adversarial training
- Data quality control

**Runtime Controls:**
- Runtime model integrity
- Runtime model confidentiality
- Model obfuscation
- Output encoding
- Resource limiting

### 5. Provide Testing Recommendations

Recommend appropriate testing approaches using the engineering tool matrix:

**Predictive AI Tools:**
- ART (Adversarial Robustness Toolbox): Evasion perturbations, poisoning resilience
- Foolbox: Geometric boundary attacks
- TextAttack: NLP adversarial attacks

**Generative AI Tools:**
- Garak: Prompt injection, alignment bypass, data leaks
- PyRIT: Multi-turn security testing
- Promptfoo: Prompt assertion variance
- Guardrails-AI, LLM Guard, NeMo Guardrails: Input/output validation

### 6. Generate Deliverables

Create comprehensive assessment deliverables:
- Threat model document (with 4-step workflow)
- Risk assessment report (with Lethal Trifecta analysis)
- Security control recommendations (with implementation parameters)
- Testing plan (with tool matrix)
- Remediation roadmap

## Decision Trees

### Is This Threat Relevant?

```
Does the system use GenAI (LLM)?
├─ YES: Consider prompt injection threats
│  ├─ Can users provide input? → Direct prompt injection
│  └─ Does system insert untrusted data? → Indirect prompt injection
└─ NO: Skip prompt injection

Does the system perform classification?
├─ YES: Consider evasion attacks
│  └─ Can attackers influence input? → Evasion threat
└─ NO: Skip evasion

Do you train your own model?
├─ YES: Consider training data threats
│  ├─ Is training data sensitive? → Disclosure, inversion, membership inference
│  └─ Is model intellectual property? → Model theft threats
└─ NO (using ready-made model):
   └─ Consider supply chain threats

Does system insert data to model input (RAG, system prompts)?
├─ YES: Consider augmentation data threats
│  ├─ Is data sensitive? → Augmentation data leakage
│  └─ Could data be manipulated? → Augmentation data manipulation
└─ NO: Skip augmentation threats

Can model trigger actions?
├─ YES: Evaluate action impact
│  ├─ Can actions send data? → Check Lethal Trifecta
│  └─ Can actions access sensitive data? → Increased impact
└─ NO: Standard impact assessment
```

### Control Selection Logic

```
For each identified threat:
1. Can the threat be eliminated?
   └─ YES: Avoid the risk (remove the capability)
   
2. Can the threat be transferred?
   └─ YES: Transfer to supplier/insurer
   
3. Can the likelihood be reduced?
   └─ YES: Implement preventive controls
   
4. Can the impact be reduced?
   └─ YES: Implement mitigating controls
   
5. Is residual risk acceptable?
   ├─ YES: Accept the risk
   └─ NO: Iterate or escalate
```

## 4-Step Threat Modeling Workflow

### Step 1: Define System Architecture and Asset Boundaries
Identify every operational component:
- Training Data Pools: in-house, public web, external vendors?
- Model Execution Boundaries: external cloud API or internal Docker/K8s?
- Context Aggregators: vector database or dynamic RAG?

### Step 2: Trace the Lethal Trifecta Vector
Examine interaction pathways for execution hazards:
- Does model output directly execute system tasks?
- Can model trigger network hooks or transmit data externally?

### Step 3: Map System Assets to Vulnerability Matrix
Consult threat catalog based on architecture:
- Classification pipeline → Prioritize evasion testing
- Chatbot with RAG → Implement indirect prompt injection defenses

### Step 4: Establish Continuous Validation Infrastructure
Integrate controls into build specs with automated adversarial scanning

## Integration with Other Frameworks

- **ISO/IEC 27090**: AI Security standard (AI Exchange provides technical foundation)
- **ISO/IEC 27091**: AI Privacy standard (AI Exchange provides technical foundation)
- **ISO/IEC 42001**: AI Management System
- **ISO/IEC 27001**: Information Security Management
- **NIST AI RMF**: AI Risk Management Framework
- **EU AI Act**: European AI regulation (AI Exchange aligned)
- **MITRE ATLAS**: Adversarial tactics and techniques
- **OWASP Top 10 for LLM**: LLM-specific risks

## Additional Resources

- OWASP AI Exchange: https://owaspai.org
- OWASP GenAI Security Project
- MITRE ATLAS: https://attack.mitre.org/matrices/enterprise/
- NIST AI RMF: https://www.nist.gov/artificial-intelligence
- ISO/IEC 42001 (AI Management System)

## Version History

- **v2.0.0** (Current): Merged Coze and Gemini versions
  - Added G.U.A.R.D. governance framework
  - Added Lethal Trifecta methodology
  - Added engineering tool matrix (ART, Foolbox, Garak, PyRIT, Promptfoo)
  - Added 4-step threat modeling workflow
  - Added ISO/IEC 27090 and 27091 mapping
  - Enhanced threat descriptions with Mechanism/Impact/Controls format
  - Expanded security checklist to 150+ items
  
- v1.0.0 (2026-07-01): Initial comprehensive release based on OWASP AI Exchange
