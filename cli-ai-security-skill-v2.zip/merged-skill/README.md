# AI Security Assessment Skill v2.0.0

A comprehensive AI/ML security assessment skill based on the OWASP AI Exchange framework — the world's most complete guide to AI security with 300+ pages of practical guidance. This **v2.0.0 merged edition** integrates engineering-focused guidance from both the original comprehensive version and the Gemini engineering version.

## Overview

This skill enables security professionals to:
- Understand and apply the OWASP AI Exchange framework
- Identify AI-specific security threats and vulnerabilities
- Assess security risks for AI/ML systems using structured methodologies
- Implement appropriate security controls with engineering parameters
- Navigate the intersection of traditional and AI-specific security
- Conduct production-ready AI security testing

## Skill Structure

```
merged-skill/
├── SKILL.md                              # Main skill definition (v2.0.0)
├── README.md                             # This file
├── references/                           # Detailed reference documents
│   ├── framework-overview.md            # OWASP AI Exchange overview + Core Tenets
│   ├── threat-taxonomy.md               # Complete AI threat classification
│   ├── controls-catalog.md              # Security controls directory
│   ├── risk-assessment.md               # Risk assessment methodology + 4-step workflow
│   ├── testing-guide.md                 # AI security testing + tool matrix
│   ├── privacy-guide.md                 # AI privacy considerations
│   ├── governance-guide.md              # AI governance framework + G.U.A.R.D.
│   ├── agentic-ai.md                   # Agentic AI security + Lethal Trifecta
│   └── genai-security.md               # Generative AI security
└── examples/                             # Templates and practical guides
    ├── threat-model-template.md         # Threat modeling template + workflow
    ├── risk-assessment-template.md      # Risk assessment + Lethal Trifecta
    └── security-checklist.md            # Comprehensive checklist (150+ items)
```

## Key Frameworks

### The G.U.A.R.D. Governance Framework

Five lifecycle stages for systematic AI security:

1. **Govern** — Maintain AI inventory, perform impact analyses, assign asset accountabilities
2. **Understand** — Map architectures against decision trees to identify applicable threats
3. **Adapt** — Integrate AI data structures into ISMS and SDLC
4. **Reduce** — Enforce data minimization, obfuscation, least privileges, guardrails
5. **Demonstrate** — Generate cryptographic lineage docs, audit trails, red-teaming telemetry

### The Lethal Trifecta

Catastrophic failure path for agentic AI — three conditions must coexist:

1. **Untrusted Data Pipeline**: Attacker controls input loading into LLM context
2. **Privileged Access**: Model/agent has authenticated access to sensitive data
3. **Autonomous Transmission**: Model can push data out (email, webhooks, etc.)

**All three = Catastrophic data exfiltration**
**Missing any one = Attack fails**

### Core Tenets of AI Security

1. **Inductive Nature Risks**: ML models define behavior statistically — being wrong is intrinsic
2. **Fluidity of Boundaries**: LLMs treat instructions and data interchangeably, breaking trust boundaries
3. **Zero Model Trust**: Assume any model can be manipulated — focus on hardening AND blast radius

## 4-Step Threat Modeling Workflow

```
Step 1: Define System Architecture and Asset Boundaries
        ├─ Training Data Pools (in-house, public, external vendors)
        ├─ Model Execution Boundaries (external API or internal)
        └─ Context Aggregators (vector DB, RAG)

Step 2: Trace the Lethal Trifecta Vector
        ├─ Model output → system tasks?
        └─ Model can transmit data externally?

Step 3: Map System Assets to Vulnerability Matrix
        ├─ Classification pipeline → Evasion testing
        └─ Chatbot with RAG → Indirect prompt injection defenses

Step 4: Establish Continuous Validation Infrastructure
        └─ Integrate controls + automated adversarial scanning
```

## Engineering Tool Matrix

| Category | Tool | Focus | Strategy |
|----------|------|-------|----------|
| **Predictive AI** | ART | Evasion perturbations, poisoning resilience | Pre-deployment pipeline |
| **Predictive AI** | Foolbox | Geometric boundary attacks | Adversarial distribution calc |
| **Generative AI** | Garak | Prompt injection, alignment bypass, data leaks | CI/CD integration |
| **Generative AI** | PyRIT | Multi-turn security testing | Security review phases |
| **Generative AI** | Promptfoo | Prompt assertion variance | Development prompt sets |

## Threat Categories

| Category | Examples | Key Controls |
|----------|----------|--------------|
| **Model Behavior Integrity** | Prompt injection, evasion, poisoning | Model Alignment, I/O Handling |
| **Training Data Confidentiality** | Data leakage, membership inference | Data Minimize, Obfuscate |
| **Model Confidentiality** | Model extraction, parameter theft | Rate Limit, Access Control |
| **Availability** | Resource exhaustion, DoS | Rate Limit, Resource Limits |
| **Input Data** | Input leakage, interception | Input Validation, Segregation |
| **Agentic Specific** | Lethal Trifecta, privilege escalation | Least Privilege, Oversight |

## Standards Alignment

This skill aligns with:
- **ISO/IEC 27090**: AI Security (AI Exchange provides technical foundation)
- **ISO/IEC 27091**: AI Privacy (AI Exchange provides technical foundation)
- **ISO/IEC 42001**: AI Management System
- **ISO/IEC 27001/27002**: Information Security Management
- **NIST AI RMF**: AI Risk Management Framework
- **MITRE ATLAS**: Adversarial Tactics, Techniques, and Procedures
- **EU AI Act**: European AI regulation
- **OWASP Top 10 for LLM**: LLM-specific risks

## Usage Example

```
User Request: "Assess security of our customer service chatbot"

1. Gather system information:
   - GenAI (LLM) based
   - Provider-hosted (OpenAI)
   - Uses RAG for company knowledge
   - Can trigger actions (create tickets)

2. Identify threats:
   - Direct prompt injection ✓
   - Indirect prompt injection ✓ (RAG data)
   - Data disclosure ✓ (training data, RAG data)
   - Augmentation data manipulation ✓
   - Resource exhaustion ✓
   - Action escalation ✓ (ticket creation)
   - Lethal Trifecta check:
     • Untrusted data: RAG documents ✓
     • Privileged access: Ticket system access ✓
     • Autonomous transmission: Ticket creation ✓
     → ALL THREE PRESENT: Critical risk

3. Assess risks:
   - Critical: Lethal Trifecta → data exfiltration
   - High risk: Prompt injection → action escalation
   - Medium risk: Data disclosure
   - Low risk: Model extraction (provider responsibility)

4. Recommend controls:
   - #PROMPT INJECTION I/O HANDLING
   - #INPUT SEGREGATION for RAG
   - #LEAST MODEL PRIVILEGE (reduce ticket permissions)
   - #OVERSIGHT (human approval for ticket creation)
   - #SENSITIVE OUTPUT HANDLING
   - #RATE LIMIT
   - Break the Trifecta by limiting one condition

5. Provide testing guidance:
   - Garak: Prompt injection testing
   - PyRIT: Multi-turn manipulation testing
   - Custom: Ticket creation escalation testing
```

## Key Reference Documents

### Framework Overview (`references/framework-overview.md`)
- OWASP AI Exchange structure and mission
- Core Tenets: Inductive Nature, Fluidity of Boundaries, Zero Model Trust
- ISO/IEC 27090 and 27091 mapping

### Threat Taxonomy (`references/threat-taxonomy.md`)
Complete classification with Mechanism/Impact/Controls format:
- Input Threats (Direct/Indirect Prompt Injection, Evasion, Model Inversion)
- Development-Time Threats (Data Poisoning, Supply Chain)
- Runtime Threats (Model Tampering, Data Leakage)
- Agentic Threats (Lethal Trifecta, Privilege Escalation)

### Controls Catalog (`references/controls-catalog.md`)
Comprehensive directory with implementation parameters:
- Governance controls (#AI PROGRAM, #SEC PROGRAM)
- Data limitation controls (#DATA MINIMIZE, #OBFUSCATE)
- Behavior limitation controls (#LEAST MODEL PRIVILEGE, #OVERSIGHT)
- Input threat controls (#PROMPT INJECTION I/O HANDLING)
- Development-time controls (#DEV SECURITY, #SUPPLY CHAIN MANAGE)
- Runtime controls (#RUNTIME MODEL INTEGRITY)

### Risk Assessment (`references/risk-assessment.md`)
- Structured risk assessment methodology
- Lethal Trifecta analysis for agentic systems
- 4-step threat modeling workflow
- Risk register maintenance

### Testing Guide (`references/testing-guide.md`)
- Penetration testing methodology
- Engineering tool matrix (ART, Foolbox, Garak, PyRIT, Promptfoo)
- Tool evaluation reference matrix
- Testing checklists

### Governance Guide (`references/governance-guide.md`)
- G.U.A.R.D. framework implementation
- AI program establishment
- ISO/IEC 27090/27091 compliance mapping
- Shadow AI management

### Agentic AI (`references/agentic-ai.md`)
- Seven layers of prompt injection protection
- Lethal Trifecta prevention strategies
- Least privilege strategies (7 approaches)
- Architecture best practices

### Generative AI (`references/genai-security.md`)
- Prompt injection (direct and indirect)
- Ready-made model security
- Secure RAG architecture
- Cultural considerations

## Templates

### Threat Model Template (`examples/threat-model-template.md`)
- System information documentation
- 4-step threat modeling workflow integration
- Lethal Trifecta assessment table
- Threat identification and risk assessment

### Risk Assessment Template (`examples/risk-assessment-template.md`)
- Comprehensive risk assessment structure
- Lethal Trifecta section
- Asset identification
- Threat analysis and vulnerability assessment

### Security Checklist (`examples/security-checklist.md`)
**150+ items** covering:
- AI Governance (14 items)
- Data Security (16 items)
- Model Security (18 items)
- Input Security (18 items)
- Output Security (15 items)
- Behavior Limitation (18 items)
- Continuous Validation (15 items)
- Agentic AI (14 items)
- Privacy (17 items)
- Incident Response (12 items)

## Key Principles

1. **Defense in Depth**: Multiple layers of security controls
2. **Least Privilege**: Minimize what models can do
3. **Data Minimization**: Limit sensitive data exposure
4. **Continuous Validation**: Ongoing monitoring and testing
5. **Supply Chain Security**: Secure all components
6. **Privacy by Design**: Integrate privacy from the start
7. **Human Oversight**: Keep humans in critical loops
8. **Zero Model Trust**: Assume models can be compromised — limit blast radius
9. **Break the Trifecta**: For agentic systems, eliminate at least one Lethal Trifecta condition

## Common Pitfalls to Avoid

1. ❌ Ignoring AI-specific threats (focusing only on conventional security)
2. ❌ Overestimating model security (models can always be wrong/manipulated)
3. ❌ Neglecting supply chain (data and model provenance is critical)
4. ❌ Insufficient monitoring (AI needs continuous validation)
5. ❌ Poor data governance (training data quality/security are foundational)
6. ❌ Missing oversight (human oversight critical for high-risk applications)
7. ❌ Inadequate testing (AI requires specialized testing approaches)
8. ❌ Implementing access control in GenAI instructions (vulnerable to injection)
9. ❌ Not considering Lethal Trifecta (agentic systems have unique failure paths)
10. ❌ Forgetting privacy (AI systems process大量 personal data)

## Resources

- **OWASP AI Exchange**: https://owaspai.org
- **OWASP GenAI Security Project**: https://genai.owasp.org
- **MITRE ATLAS**: https://attack.mitre.org/matrices/enterprise/
- **OpenCRE**: https://opencre.org
- **NIST AI RMF**: https://www.nist.gov/artificial-intelligence
- **ISO/IEC 27090 (AI Security)**: https://www.iso.org
- **ISO/IEC 27091 (AI Privacy)**: https://www.iso.org

## Version History

- **v2.0.0** (Current): Merged Coze and Gemini versions
  - G.U.A.R.D. governance framework
  - Lethal Trifecta methodology
  - Engineering tool matrix
  - 4-step threat modeling workflow
  - ISO/IEC 27090/27091 mapping
  - Mechanism/Impact/Controls threat format
  - 150+ item security checklist

- **v1.0.0** (2026-07-01): Initial comprehensive release based on OWASP AI Exchange

## License

This skill is based on the OWASP AI Exchange, which is released under CC0 1.0 (public domain). You can use any part freely without copyright and without attribution.

## Contributing

The OWASP AI Exchange is an open, collaborative project. Contributions welcome at https://owaspai.org
