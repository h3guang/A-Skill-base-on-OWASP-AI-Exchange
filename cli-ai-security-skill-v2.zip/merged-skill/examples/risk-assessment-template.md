# AI Risk Assessment Template

## Assessment Information

| Field | Value |
|-------|-------|
| **System Name** | |
| **Assessment Date** | |
| **Assessor(s)** | |
| **Review Date** | |
| **Classification** | Confidential / Internal / Public |

---

## Executive Summary

### System Overview
<!-- Brief description of the AI system -->

### Key Findings
<!-- Top 3-5 critical findings -->

1. 
2. 
3. 

### Overall Risk Level
- [ ] Critical
- [ ] High
- [ ] Medium
- [ ] Low

### Recommendation
<!-- Go/No-Go/Conditional -->

---

## Scope

### In Scope
- [List of components, features, integrations]

### Out of Scope
- [List of excluded items]

### Assumptions
- [Key assumptions made during assessment]

### Limitations
- [Known limitations of this assessment]

---

## Asset Identification

### AI-Specific Assets

| Asset | Description | Sensitivity | Criticality | Owner |
|-------|-------------|-------------|-------------|-------|
| Training Data | | High/Med/Low | H/M/L | |
| Model Parameters | | | | |
| System Prompts | | | | |
| RAG/Augmentation Data | | | | |
| User Input | | | | |
| Model Output | | | | |
| Documentation | | | | |

### Conventional IT Assets

| Asset | Description | Sensitivity | Criticality | Owner |
|-------|-------------|-------------|-------------|-------|
| Application Servers | | | | |
| Databases | | | | |
| APIs | | | | |
| Network Infrastructure | | | | |

---

## The Lethal Trifecta Analysis (Agentic AI)

For agentic AI systems, this section assesses the catastrophic failure path.

### Trifecta Condition Assessment

| Condition | Question | Response | Evidence |
|-----------|----------|----------|----------|
| **1. Untrusted Data Pipeline** | Does the system accept external data that attacker can control? | Yes/No | |
| | Can attacker inject instructions via RAG, web scraping, user forms? | Yes/No | |
| | Is data inserted into model context without user consent? | Yes/No | |
| **2. Privileged Access** | Does the model/agent have access to sensitive systems? | Yes/No | |
| | Can it access databases, APIs, or files beyond its immediate task? | Yes/No | |
| | Are permissions granted based on model identity rather than user? | Yes/No | |
| **3. Autonomous Transmission** | Can the model/agent send data externally? | Yes/No | |
| | Are there email, webhook, or file creation capabilities? | Yes/No | |
| | Can data be pushed without explicit user approval? | Yes/No | |

### Trifecta Risk Level

| Condition Present | Risk Level | Required Action |
|------------------|------------|----------------|
| All three | **CRITICAL** | Must break at least one condition before deployment |
| Two | **HIGH** | Implement controls to break/monitor third condition |
| One | **MEDIUM** | Document and monitor for escalation |
| None | **LOW** | Standard risk management applies |

### Trifecta Mitigation Plan

| Condition | Mitigation Strategy | Controls | Status |
|-----------|---------------------|----------|--------|
| Untrusted Data Pipeline | Input segregation / Data validation | | |
| Privileged Access | Least privilege / User-scoped permissions | | |
| Autonomous Transmission | Egress filtering / Action approval | | |

---

## Threat Analysis

### Applicable Threats

For each threat identified in the threat model, document the detailed analysis.

#### Threat 1: [Threat Name]

| Attribute | Assessment |
|-----------|------------|
| **Threat ID** | |
| **Category** | Input/Development/Runtime/Supply Chain/Conventional |
| **Description** | |
| **Attack Surface** | |
| **Attack Scenario** | Step-by-step description of how attack could occur |
| **Prerequisites** | What attacker needs to execute this attack |

**Likelihood Assessment**:

| Factor | Rating (1-5) | Justification |
|--------|-------------|---------------|
| Attacker access | | |
| Attacker capability | | |
| System vulnerability | | |
| Attacker motivation | | |
| Detection difficulty | | |
| **Overall Likelihood** | | |

**Impact Assessment**:

| Impact Area | Rating (1-5) | Justification |
|-------------|-------------|---------------|
| Financial | | |
| Operational | | |
| Reputational | | |
| Legal/Compliance | | |
| Safety | | |
| **Overall Impact** | | |

**Risk Level**: Likelihood × Impact = Critical / High / Medium / Low

### Threat Summary Table

| ID | Threat | Likelihood | Impact | Risk Level | Priority |
|----|--------|------------|--------|------------|----------|
| T1 | | | | | |
| T2 | | | | | |
| T3 | | | | | |

---

## Vulnerability Assessment

### Current Controls

| Control | Category | Status | Effectiveness | Notes |
|---------|----------|--------|---------------|-------|
| | Prevention/Detection/Correction | Implemented/Partial/Missing | High/Med/Low | |

### Vulnerabilities

| ID | Vulnerability | Related Threat | Severity | Exploitability |
|----|--------------|---------------|----------|----------------|
| V1 | | | H/M/L | Easy/Med/Hard |

---

## Risk Treatment

### Risk Treatment Decisions

| Risk ID | Risk Level | Treatment | Rationale | Residual Risk |
|---------|------------|-----------|-----------|---------------|
| R1 | | Mitigate/Transfer/Avoid/Accept | | H/M/L |

### Mitigation Plan

For each risk being mitigated:

#### Risk R1: [Risk Name]

**Controls to Implement**:

| Control | Type | Implementation | Owner | Timeline |
|---------|------|----------------|-------|----------|
| | Preventive | | | |

**Implementation Details**:
- Step 1:
- Step 2:
- Step 3:

**Success Criteria**:
- [ ] 

**Verification Method**:
- How will we verify the control is effective?

---

## Compliance Assessment

### Regulatory Requirements

| Regulation | Requirement | Status | Gap | Action |
|-----------|-------------|--------|-----|--------|
| GDPR | | | | |
| EU AI Act | | | | |
| ISO 27001 | | | | |
| ISO/IEC 27090 | | | | |
| ISO/IEC 27091 | | | | |
| Industry-specific | | | | |

### Standards Alignment

| Standard | Coverage | Gaps | Action Required |
|----------|----------|------|----------------|
| ISO/IEC 42001 | | | |
| ISO/IEC 27090 | | | |
| ISO/IEC 27091 | | | |
| NIST AI RMF | | | |
| MITRE ATLAS | | | |

---

## Privacy Assessment

### Data Processing

| Data Type | Purpose | Legal Basis | Retention | Minimization |
|-----------|---------|-------------|-----------|--------------|
| | | | | |

### Privacy Risks

| Risk | Likelihood | Impact | Mitigation | Residual |
|------|-----------|--------|------------|----------|
| | | | | |

### Data Subject Rights

| Right | Supported? | Implementation |
|-------|-----------|----------------|
| Access | | |
| Erasure | | |
| Rectification | | |
| Portability | | |
| Objection | | |

---

## Supply Chain Assessment

### Suppliers

| Supplier | Service | Data Access | Risk Level | Controls |
|----------|---------|-------------|------------|----------|
| | | | | |

### Third-Party Risks

| Risk | Source | Impact | Mitigation |
|------|--------|--------|------------|
| | | | |

---

## Recommendations

### Immediate Actions (0-30 days)

| # | Action | Owner | Priority | Effort |
|---|--------|-------|----------|--------|
| 1 | | | Critical | |

### Short-Term Actions (30-90 days)

| # | Action | Owner | Priority | Effort |
|---|--------|-------|----------|--------|
| 1 | | | High | |

### Medium-Term Actions (90-180 days)

| # | Action | Owner | Priority | Effort |
|---|--------|-------|----------|--------|
| 1 | | | Medium | |

### Long-Term Strategy (180+ days)

| # | Action | Owner | Priority | Effort |
|---|--------|-------|----------|--------|
| 1 | | | Low | |

---

## Risk Register

| ID | Risk | Category | Likelihood | Impact | Level | Treatment | Owner | Status | Review Date |
|----|------|----------|-----------|--------|-------|-----------|-------|--------|-------------|
| | | | | | | | | Open/Closed/Mitigated | |

---

## Appendices

### Appendix A: Evidence Collected
- [List of documents reviewed, interviews conducted, tests performed]

### Appendix B: Tools Used
- [Assessment tools and methodologies]

### Appendix C: References
- OWASP AI Exchange
- ISO/IEC 27090 (AI Security)
- ISO/IEC 27091 (AI Privacy)
- Applicable standards and regulations

### Appendix D: Glossary
- [Key terms and definitions]

---

## Sign-off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Assessor | | | |
| Security Lead | | | |
| System Owner | | | |
| Risk Owner | | | |
| Compliance Officer | | | |
