# AI Security Assessment Checklist

Use this checklist to perform comprehensive AI security assessments. This expanded v2.0.0 checklist includes **150+ items** merged from both Coze and Gemini versions. Mark each item as ✅ (Implemented), ⚠️ (Partial), ❌ (Not Implemented), or N/A (Not Applicable).

---

## 1. AI Governance

### 1.1 AI Program
- [ ] AI inventory maintained (all AI systems documented)
- [ ] Impact assessments performed for AI initiatives
- [ ] AI risks included in enterprise risk management
- [ ] Responsibilities assigned (model owner, data owner)
- [ ] AI literacy program in place
- [ ] AI innovation process defined
- [ ] Board/executive awareness of AI risks
- [ ] Central corporate register of AI initiatives established
- [ ] Asset ownership clearly assigned for training data, model parameters, output tracking
- [ ] Regulatory alignment verified (GDPR, EU AI Act)

### 1.2 Security Program
- [ ] AI-specific assets added to security management system
- [ ] AI-specific threats included in threat models
- [ ] AI assets included in security monitoring
- [ ] Security team trained on AI threats
- [ ] AI incident response procedures defined
- [ ] AI security honeypots considered
- [ ] ISO/IEC 27090 (AI Security) alignment addressed
- [ ] ISO/IEC 27091 (AI Privacy) alignment addressed

### 1.3 Secure Development Program
- [ ] Data science development integrated with SDLC
- [ ] Code review includes AI-specific concerns
- [ ] Static analysis covers AI code patterns
- [ ] Security requirements include AI-specific requirements
- [ ] Threat modeling includes AI threats (4-step workflow)
- [ ] AI engineers trained on secure development
- [ ] AI-specific engineering practices documented

### 1.4 Compliance
- [ ] Applicable AI regulations identified
- [ ] GDPR compliance assessed (if personal data)
- [ ] EU AI Act classification determined
- [ ] Industry-specific regulations addressed
- [ ] Compliance monitoring in place
- [ ] Documentation maintained for regulators
- [ ] Conformity assessment completed (if high-risk AI)

---

## 2. Data Security

### 2.1 Data Minimization
- [ ] Only necessary data collected for training
- [ ] Unnecessary fields/records removed
- [ ] Data reviewed for purpose limitation
- [ ] Retention periods defined and enforced
- [ ] Original data preserved separately with access controls
- [ ] Differential privacy considered/implemented
- [ ] Statistical noise added to sensitive training data

### 2.2 Data Obfuscation
- [ ] Sensitive data obfuscated where possible
- [ ] Differential privacy considered/implemented
- [ ] Tokenization applied to sensitive fields
- [ ] Encryption used for data at rest
- [ ] Access controls on training data
- [ ] PATE (Private Aggregation of Teacher Ensembles) considered

### 2.3 Data Quality
- [ ] Data quality controls implemented
- [ ] Data provenance documented
- [ ] Data lineage tracked
- [ ] Anomaly detection on training data
- [ ] Regular data quality reviews
- [ ] Poisoning detection mechanisms in place

### 2.4 Data Segregation
- [ ] Development data segregated from production
- [ ] Training data access restricted by role
- [ ] Test data separated from training data
- [ ] Different environment zones (external, dev, training)
- [ ] Separate environments for different data sensitivity levels

---

## 3. Model Security

### 3.1 Development-Time Security
- [ ] Development environment secured
- [ ] Model parameters protected
- [ ] Source code/config secured
- [ ] Version control for models and data
- [ ] Integrity checks on model artifacts
- [ ] Model signing implemented or planned
- [ ] Cryptographic verification of model weights
- [ ] Secure build pipeline for model deployment

### 3.2 Supply Chain Security
- [ ] Model providers assessed for security
- [ ] Data provenance verified
- [ ] Model authenticity verified (signatures/checksums)
- [ ] Supply chain dependencies documented
- [ ] Third-party model assessment performed
- [ ] Contractual security requirements in place
- [ ] SBOM/AIBOM maintained
- [ ] External model registries verified with hash checks
- [ ] Open-source components scanned for vulnerabilities

### 3.3 Runtime Security
- [ ] Model integrity verified at runtime
- [ ] Model parameters protected (encryption/TEE)
- [ ] Model obfuscation considered
- [ ] Runtime tampering detection
- [ ] Model rollback capability
- [ ] Secure model serving infrastructure
- [ ] Model versioning and rollback procedures

### 3.4 Model Confidentiality
- [ ] Model protected from extraction
- [ ] Access controls on model parameters
- [ ] API rate limiting implemented
- [ ] Model watermarking considered
- [ ] Monitoring for model extraction attempts
- [ ] Query rate limiting to prevent exfiltration

---

## 4. Input Security

### 4.1 Input Validation
- [ ] Input schema validation
- [ ] Input sanitization
- [ ] Size limits enforced
- [ ] Rate limiting implemented
- [ ] Authentication required where appropriate
- [ ] Input monitoring and logging
- [ ] Type checking for structured inputs

### 4.2 Prompt Injection (GenAI)
- [ ] Direct prompt injection defenses
- [ ] Indirect prompt injection defenses
- [ ] Input segregation (marking untrusted data)
- [ ] Unicode normalization
- [ ] Instruction detection mechanisms
- [ ] LLM-as-judge detection (if applicable)
- [ ] Regular testing of injection resistance
- [ ] Structured message formats (system/user/tool roles)
- [ ] Guardrail layers at API entrance/exit gates

### 4.3 Evasion Prevention
- [ ] Adversarial training performed
- [ ] Input distortion defenses
- [ ] Model robustness testing
- [ ] Monitoring for evasion attempts
- [ ] Confidence score obscuring
- [ ] Out-of-distribution detection
- [ ] Spatial reconstruction error monitoring

### 4.4 Resource Protection
- [ ] DoS protection in place
- [ ] Resource limits per user/request
- [ ] Cost controls for paid API services
- [ ] Availability monitoring
- [ ] Circuit breakers implemented
- [ ] Token consumption thresholds configured
- [ ] Recursive/nested prompt detection

---

## 5. Output Security

### 5.1 Output Validation
- [ ] Output filtering for sensitive data
- [ ] Output encoding (prevent XSS, injection)
- [ ] Content safety filters
- [ ] Output monitoring and logging
- [ ] PII detection in outputs
- [ ] Grounding checks for hallucinations

### 5.2 Data Leakage Prevention
- [ ] Training data not leaked in outputs
- [ ] System prompts not exposed
- [ ] RAG data not leaked
- [ ] Membership inference resistance
- [ ] Model inversion resistance
- [ ] Confidence scores obscured (where applicable)

### 5.3 Behavioral Controls
- [ ] Human oversight for critical actions
- [ ] Automated oversight mechanisms
- [ ] Action approval workflows
- [ ] Anomalous output detection
- [ ] Output grounding checks
- [ ] Blast radius limitation configured

---

## 6. Behavior Limitation

### 6.1 Least Privilege
- [ ] Model permissions minimized
- [ ] Task-based permission scoping
- [ ] Ephemeral permissions used
- [ ] Authorization NOT in GenAI instructions
- [ ] Access control in application layer
- [ ] Sub-agent permission downgrading
- [ ] User-scoped permissions (not agent-native)
- [ ] Risk elevation when untrusted data detected

### 6.2 Model Alignment
- [ ] Safety training performed
- [ ] RLHF implemented (for GenAI)
- [ ] System prompts define boundaries
- [ ] Guardrails implemented
- [ ] Regular alignment testing
- [ ] Red team testing of alignment

### 6.3 Oversight
- [ ] Human-in-the-loop for critical actions
- [ ] Automated behavioral monitoring
- [ ] Anomaly detection
- [ ] Alert thresholds configured
- [ ] Blast radius limitation
- [ ] Pattern-based detection active

### 6.4 Transparency & Explainability
- [ ] Users informed about AI involvement
- [ ] Model behavior documented
- [ ] Explainability mechanisms available
- [ ] Decision audit trail
- [ ] Transparency about limitations
- [ ] Model cards maintained

---

## 7. Continuous Validation

### 7.1 Testing
- [ ] Pre-deployment testing completed
- [ ] Adversarial testing performed
- [ ] Red team testing conducted
- [ ] Privacy attack testing done
- [ ] Regression testing for model updates
- [ ] Lethal Trifecta testing (agentic AI)
- [ ] Automated adversarial scanning in CI/CD

### 7.2 Monitoring
- [ ] Model performance monitored
- [ ] Drift detection implemented
- [ ] Anomaly detection active
- [ ] Usage patterns monitored
- [ ] Security alerts configured
- [ ] Behavioral baselines established

### 7.3 Continuous Improvement
- [ ] Regular security assessments
- [ ] Threat intelligence integration
- [ ] Control effectiveness reviews
- [ ] Incident lessons learned applied
- [ ] Emerging threat monitoring
- [ ] Tool matrix updated regularly

---

## 8. Agentic AI (If Applicable)

### 8.1 Agent Architecture
- [ ] Defense in depth implemented
- [ ] Blast radius controls in place
- [ ] Least privilege per agent
- [ ] Inter-agent communication secured
- [ ] Working memory protected
- [ ] Orchestration separated from execution
- [ ] Zero trust for agent interactions

### 8.2 Prompt Injection Defense (Seven Layers)
- [ ] Layer 1: Model alignment
- [ ] Layer 2: I/O handling
- [ ] Layer 3: Human oversight (moderate use)
- [ ] Layer 4: Automated oversight
- [ ] Layer 5: User-based least privilege
- [ ] Layer 6: Intent-based least privilege
- [ ] Layer 7: Just-in-time authorization

### 8.3 Lethal Trifecta Prevention
- [ ] Data: Untrusted data controlled
- [ ] Access: Sensitive data access limited
- [ ] Send: Data egress controlled
- [ ] At least one condition broken/monitored
- [ ] Trifecta risk level documented
- [ ] Trifecta mitigation plan in place

### 8.4 Tool Security
- [ ] Tool access minimized
- [ ] Tool inputs validated
- [ ] Tool outputs sanitized
- [ ] Tool call monitoring
- [ ] Tool abuse detection
- [ ] Circuit breakers on tool usage

---

## 9. Privacy

### 9.1 Privacy by Design
- [ ] DPIA/PIA completed
- [ ] Data minimization applied
- [ ] Purpose limitation enforced
- [ ] Storage limitation implemented
- [ ] Accuracy measures in place
- [ ] Privacy-preserving techniques considered

### 9.2 Data Subject Rights
- [ ] Access requests supported
- [ ] Erasure capability (including model retraining)
- [ ] Rectification supported
- [ ] Portability supported
- [ ] Objection handling
- [ ] Right to explanation for automated decisions

### 9.3 Consent & Legal Basis
- [ ] Lawful basis documented
- [ ] Consent mechanisms (if required)
- [ ] Consent withdrawal supported
- [ ] Special category data protections
- [ ] Children's data protections (if applicable)

### 9.4 Cross-Border
- [ ] Data transfer restrictions assessed
- [ ] SCCs or adequacy decisions in place
- [ ] International compliance addressed
- [ ] Vendor data processing agreements in place

---

## 10. Incident Response

### 10.1 Preparation
- [ ] AI-specific incident response plan
- [ ] Incident detection procedures
- [ ] Response team trained
- [ ] Communication plan defined
- [ ] Evidence preservation procedures
- [ ] Lethal Trifecta incident scenarios addressed

### 10.2 Detection
- [ ] AI anomaly detection
- [ ] Log monitoring for AI events
- [ ] Alert rules configured
- [ ] Threat intelligence feeds
- [ ] Automated alert triage

### 10.3 Response
- [ ] Containment procedures
- [ ] Investigation procedures
- [ ] Recovery procedures
- [ ] Post-incident review process
- [ ] Model rollback procedures tested

---

## Assessment Summary

| Category | ✅ Implemented | ⚠️ Partial | ❌ Not Implemented | N/A | Score |
|----------|---------------|-----------|-------------------|-----|-------|
| 1. Governance | /10 | /10 | /10 | /10 | % |
| 2. Data Security | /16 | /16 | /16 | /16 | % |
| 3. Model Security | /18 | /18 | /18 | /18 | % |
| 4. Input Security | /18 | /18 | /18 | /18 | % |
| 5. Output Security | /15 | /15 | /15 | /15 | % |
| 6. Behavior Limitation | /18 | /18 | /18 | /18 | % |
| 7. Continuous Validation | /15 | /15 | /15 | /15 | % |
| 8. Agentic AI | /14 | /14 | /14 | /14 | % |
| 9. Privacy | /17 | /17 | /17 | /17 | % |
| 10. Incident Response | /12 | /12 | /12 | /12 | % |

### Overall Score: ___%

### Risk Level: Critical / High / Medium / Low

---

## Lethal Trifecta Summary (Agentic AI Only)

| Condition | Status | Controls |
|-----------|--------|----------|
| Untrusted Data Pipeline | Present/Mitigated | |
| Privileged Access | Present/Mitigated | |
| Autonomous Transmission | Present/Mitigated | |
| **Overall Risk** | Critical/High/Medium/Low | |

---

## Recommendations

### Priority 1 (Immediate)
1. 
2. 
3. 

### Priority 2 (Short-term)
1. 
2. 
3. 

### Priority 3 (Medium-term)
1. 
2. 
3. 

---

## Sign-off

| Role | Name | Date |
|------|------|------|
| Assessor | | |
| Security Lead | | |
| System Owner | | |

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-07-01 | Initial comprehensive checklist (137 items) |
| 2.0 | Current | Merged Coze and Gemini versions (150+ items), added Lethal Trifecta section, expanded all categories |
