# AI Threat Model Template

## System Information

| Field | Value |
|-------|-------|
| **System Name** | |
| **System Owner** | |
| **Date** | |
| **Version** | |
| **Assessor(s)** | |

## System Description

### Purpose
<!-- What does this AI system do? -->

### AI Type
- [ ] Generative AI (LLM, image generation, etc.)
- [ ] Predictive AI (classification, regression, recommendation)
- [ ] Agentic AI (autonomous agents, multi-agent systems)
- [ ] Heuristic/Rule-based AI

### Architecture

```
[User] → [Input] → [Preprocessing] → [Model] → [Postprocessing] → [Output]
                                                        ↓
                                                   [Actions/Tools]
                                                        ↓
                                                   [External Systems]
```

### Model Details

| Field | Value |
|-------|-------|
| **Model Type** | |
| **Training Method** | Self-trained / Fine-tuned / Ready-made (API) / Ready-made (self-hosted) |
| **Provider** (if applicable) | |
| **Framework** | |
| **Input Type** | Text / Image / Audio / Structured Data / Mixed |
| **Output Type** | Text / Image / Classification / Action / Mixed |

### Data

| Data Type | Source | Sensitivity | Retention |
|-----------|--------|-------------|-----------|
| Training Data | | | |
| Validation Data | | | |
| Test Data | | | |
| User Input | | | |
| Augmentation Data (RAG) | | | |
| System Prompts | | | |

### Integration Points

| Integration | Type | Data Flow | Trust Level |
|-------------|------|-----------|-------------|
| | API / Database / File / Agent | | High/Medium/Low |

### Actions Capabilities

| Action | Description | Privilege Level |
|--------|-------------|-----------------|
| | | |

---

## 4-Step Threat Modeling Workflow

### Step 1: Define System Architecture and Asset Boundaries

**Training Data Pools:**
- [ ] Are datasets generated in-house?
- [ ] Scraped from public web paths?
- [ ] Imported from external vendors?

**Model Execution Boundaries:**
- [ ] External cloud API (third-party managed)?
- [ ] Internally hosted using open-source weights via Docker/K8s?
- [ ] Hybrid deployment?

**Context Aggregators:**
- [ ] Vector database for RAG?
- [ ] Dynamic Retrieval-Augmented Generation (RAG)?
- [ ] Static system prompts only?

### Step 2: Trace the Lethal Trifecta Vector

For agentic AI systems, examine interaction pathways for execution hazards:

**Untrusted Data Pipeline:**
- [ ] System accepts external data (RAG, user input, web scraping)?
- [ ] Attacker can control what data enters the model context?
- [ ] Data inserted without user consent/awareness?

**Privileged Access:**
- [ ] Model/agent has access to sensitive systems?
- [ ] Can model access databases, APIs, or files beyond immediate task?
- [ ] Permissions granted based on model/agent identity rather than user?

**Autonomous Transmission:**
- [ ] Can model/agent send data externally?
- [ ] Are there email, webhook, or file creation capabilities?
- [ ] Can data be pushed without explicit user approval?

**Lethal Trifecta Assessment:**

| Condition | Present? | Risk Level |
|-----------|----------|------------|
| Untrusted Data Pipeline | Yes/No | |
| Privileged Access | Yes/No | |
| Autonomous Transmission | Yes/No | |
| **Overall (all three = Critical)** | | |

### Step 3: Map System Assets to Vulnerability Matrix

Based on architecture type, identify applicable threats:

| Architecture Type | Primary Threats to Consider |
|------------------|---------------------------|
| Classification pipeline (transaction scoring) | [ ] Test-time evasion anomalies |
| User-facing chatbot with RAG context | [ ] Indirect prompt injections, I/O data leakage |
| Agentic system with tool access | [ ] Lethal Trifecta, privilege escalation |
| Multi-modal system | [ ] Cross-modal prompt injection, output manipulation |
| Self-trained model on sensitive data | [ ] Data poisoning, membership inference, model inversion |

### Step 4: Establish Continuous Validation Infrastructure

- [ ] Deploy automated adversarial scanning checks into validation cycles
- [ ] Run automated tests before deploying updated weights into live serving setups
- [ ] Establish rollback procedures for model updates
- [ ] Set up continuous monitoring for model behavior drift

---

## Threat Identification

Use the decision tree to identify applicable threats. For each threat, document:
- Whether it applies
- Why it applies (context)
- Initial severity assessment

### Model Behavior Integrity Threats

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| Direct Prompt Injection | Yes/No/N/A | | |
| Indirect Prompt Injection | Yes/No/N/A | | |
| Evasion Attack | Yes/No/N/A | | |
| Direct Runtime Model Poisoning | Yes/No/N/A | | |
| Direct Development-time Model Poisoning | Yes/No/N/A | | |
| Data Poisoning | Yes/No/N/A | | |
| Supply Chain Model Poisoning | Yes/No/N/A | | |
| Supply Chain Data Poisoning | Yes/No/N/A | | |
| Augmentation Data Manipulation | Yes/No/N/A | | |

### Data Confidentiality Threats

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| Disclosure in Output | Yes/No/N/A | | |
| Model Inversion | Yes/No/N/A | | |
| Membership Inference | Yes/No/N/A | | |
| Direct Training Data Leak | Yes/No/N/A | | |
| Direct Augmentation Data Leak | Yes/No/N/A | | |
| Input Data Leak | Yes/No/N/A | | |

### Model Confidentiality Threats

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| Model Exfiltration | Yes/No/N/A | | |
| Direct Runtime Model Leak | Yes/No/N/A | | |
| Direct Development-time Model Leak | Yes/No/N/A | | |

### Availability Threats

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| AI Resource Exhaustion | Yes/No/N/A | | |

### Conventional Security Threats

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| Output Contains Conventional Injection | Yes/No/N/A | | |
| Generic Runtime Security Threats | Yes/No/N/A | | |
| Conventional Development/Supply Chain Threats | Yes/No/N/A | | |

### Agentic AI Threats (if applicable)

| Threat | Applies? | Context | Initial Severity |
|--------|----------|---------|-----------------|
| Privilege Escalation | Yes/No/N/A | | |
| Working Memory Manipulation | Yes/No/N/A | | |
| Inter-Agent Communication Attack | Yes/No/N/A | | |
| Tool/API Abuse | Yes/No/N/A | | |
| Lethal Trifecta (Data + Access + Send) | Yes/No/N/A | | |

---

## Risk Assessment

For each applicable threat, assess likelihood and impact.

### Likelihood Factors

| Factor | Rating | Notes |
|--------|--------|-------|
| Attacker access opportunity | H/M/L | |
| Attacker capabilities/budget | H/M/L | |
| System susceptibility | H/M/L | |
| Attacker motivation | H/M/L | |
| Number of potential attackers | H/M/L | |
| Historical incidents/attempts | H/M/L | |

### Risk Matrix

| Threat | Likelihood | Impact | Risk Level | Priority |
|--------|------------|--------|------------|----------|
| | H/M/L | H/M/L | Critical/High/Medium/Low | 1/2/3/4 |

### Lethal Trifecta Risk Level (Agentic AI Only)

| Trifecta Condition | Status | Controls in Place |
|-------------------|--------|------------------|
| Untrusted Data Pipeline | Present/Mitigated | |
| Privileged Access | Present/Mitigated | |
| Autonomous Transmission | Present/Mitigated | |
| **Overall Risk Level** | | |

---

## Control Mapping

For each identified risk, map applicable controls.

| Threat/Risk | Preventive Controls | Detective Controls | Corrective Controls | Owner |
|-------------|--------------------|--------------------|--------------------|-------| 
| | | | | |

### Control Gap Analysis

| Required Control | Status | Gap | Action Required |
|-----------------|--------|-----|-----------------|
| AI Program | | | |
| Security Program | | | |
| Data Minimization | | | |
| Least Model Privilege | | | |
| Input Validation | | | |
| Output Filtering | | | |
| Monitoring | | | |
| Supply Chain Management | | | |
| Lethal Trifecta Mitigation | | | (If applicable) |

---

## Responsible AI Considerations

| Consideration | Status | Notes |
|--------------|--------|-------|
| Bias assessment | | |
| Fairness evaluation | | |
| Transparency measures | | |
| Human oversight | | |
| Explainability | | |
| Privacy compliance | | |
| Regulatory compliance | | |

---

## Recommendations

### Immediate Actions (Critical/High Risk)

| # | Action | Owner | Timeline |
|---|--------|-------|----------|
| 1 | | | |

### Short-Term Improvements

| # | Action | Owner | Timeline |
|---|--------|-------|----------|
| 1 | | | |

### Long-Term Strategy

| # | Action | Owner | Timeline |
|---|--------|-------|----------|
| 1 | | | |

---

## Review and Sign-off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| System Owner | | | |
| Security Lead | | | |
| AI Engineer | | | |
| Data Protection Officer | | | |

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | | | Initial threat model |
| 2.0 | | | Added Lethal Trifecta analysis |
